# Asset manifest — Industry → Intelligence

Scenes are defined in `src/lib/content.ts` (`scenes`). Each accepts `image` and optional `video`; setting `video` swaps a still for a rendered camera move without layout changes.

| # | Scene | Current asset | Status | Final asset needed |
|---|-------|---------------|--------|--------------------|
| 01 | Manufacturing | `src/assets/scene-01-manufacturing.jpg` (AI-generated still) | Placeholder | Rendered forward dolly through facility, 1920×1080 MP4/WebM or image sequence, ~4s |
| 02 | Engineering | `scene-02-engineering.jpg` (AI-generated wireframe still) | Placeholder | Same camera path as 01 rendered as CAD wireframe (true morph needs matched 3D source) |
| 03 | Construction | `scene-03-construction.jpg` (AI-generated still) | Placeholder | Vertical crane-up along structure; geometry matching scene 04 |
| 04 | Real estate | `scene-04-realestate.jpg` (AI-generated still) | Placeholder | Same building completed; push-in to façade grid |
| 05 | Intelligence | Code-built illustrative UI (`IntelligenceUI.tsx`) | Illustrative data | Real product screenshots / screen recordings |
| — | Case studies | Reuse scene stills | Placeholder | Product screenshots, walkthrough videos per project |
| — | Portrait | Dashed placeholder | Missing | Professional portrait, 4:5 |

## Production improvements required
1. Replace scene stills with a single matched 3D/rendered camera path so transitions are true morphs, not crossfades.
2. Real product screenshots + walkthrough videos for all four projects.
3. Confirm each project's status (Deployed / Pilot / Prototype / Research) and the patent application number.
4. Real LinkedIn URL and email; connect contact form delivery (currently validates only).
5. Portrait photography; favicon and social share image.
