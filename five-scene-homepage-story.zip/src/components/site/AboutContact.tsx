import { useState, type FormEvent } from "react";

export function About() {
  return (
    <section id="about" aria-labelledby="about-h" className="dark bg-graphite text-foreground">
      <div className="mx-auto grid max-w-[1600px] grid-cols-12 gap-6 px-6 py-28 md:px-10">
        <p className="label col-span-12 text-copper md:col-span-3">About</p>
        <div className="col-span-12 md:col-span-4">
          <div className="flex aspect-[4/5] items-end border border-dashed border-border bg-charcoal p-5">
            <p className="label text-steel">Portrait placeholder — photo to be supplied</p>
          </div>
        </div>
        <div className="col-span-12 md:col-span-5">
          <h2 id="about-h" className="display text-6xl md:text-7xl">
            Swayam Singh
          </h2>
          <p className="label mt-3 text-muted-foreground">AI & Software Solutions Consultant</p>
          <p className="mt-10 text-xl leading-relaxed">
            I work at the intersection of software engineering, artificial intelligence, and industrial operations,
            designing practical systems that simplify complex workflows.
          </p>
          <dl className="mt-12 divide-y divide-border border-y border-border">
            {[
              ["Experience", "Consulting across manufacturing and EPC operations — production tracking, engineering automation, and internal business software."],
              ["Education", "B.Tech in Artificial Intelligence and Machine Learning."],
              ["Research", "Part of the team behind a published patent application on multimodal AI for early detection of physician burnout."],
            ].map(([k, v]) => (
              <div key={k} className="grid grid-cols-3 gap-4 py-5">
                <dt className="label text-steel">{k}</dt>
                <dd className="col-span-2 text-sm leading-relaxed text-muted-foreground">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}

const field = "w-full border-0 border-b border-input bg-transparent py-3 text-base outline-none focus:border-copper";

export function Contact() {
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (e.currentTarget.checkValidity()) setSent(true);
  };
  return (
    <section id="contact" aria-labelledby="contact-h" className="mx-auto max-w-[1600px] px-6 py-32 md:px-10">
      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 md:col-span-7">
          <h2 id="contact-h" className="display text-[clamp(3.5rem,8vw,8.5rem)]">
            Let's build something <span className="text-copper">that actually works.</span>
          </h2>
          <p className="mt-8 max-w-md text-lg text-muted-foreground">
            Have an operational challenge worth solving? Let's explore how software and automation could help.
          </p>
          <div className="mt-10 flex gap-8">
            <span className="label text-muted-foreground">LinkedIn — link pending</span>
            <span className="label text-muted-foreground">Email — address pending</span>
          </div>
        </div>
        <form onSubmit={submit} className="col-span-12 space-y-6 md:col-span-4 md:col-start-9" aria-label="Project enquiry">
          {sent ? (
            <div role="status" className="border border-border p-6">
              <p className="display text-3xl">Thanks — noted.</p>
              <p className="mt-3 text-sm text-muted-foreground">
                Prototype: this form validates but doesn't deliver messages yet. Delivery will be connected before launch.
              </p>
            </div>
          ) : (
            <>
              {[
                ["name", "Name", "text"],
                ["company", "Company", "text"],
                ["email", "Email", "email"],
              ].map(([n, l, t]) => (
                <label key={n} className="block">
                  <span className="label text-muted-foreground">{l}</span>
                  <input name={n} type={t} required={n !== "company"} maxLength={200} className={field} />
                </label>
              ))}
              <label className="block">
                <span className="label text-muted-foreground">Industry</span>
                <select name="industry" required className={field} defaultValue="">
                  <option value="" disabled>Select</option>
                  {["Manufacturing", "EPC & Engineering", "Construction", "Real Estate", "Other"].map((o) => (
                    <option key={o}>{o}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="label text-muted-foreground">Project challenge</span>
                <textarea name="challenge" required rows={4} maxLength={2000} className={field} />
              </label>
              <button type="submit" className="label w-full bg-charcoal px-6 py-4 text-paper transition-colors hover:bg-copper">
                Discuss a project ↗
              </button>
            </>
          )}
        </form>
      </div>
      <footer className="mt-32 flex justify-between border-t border-border pt-6">
        <span className="label text-muted-foreground">Swayam Singh · Industry → Intelligence</span>
        <a href="#top" className="label text-muted-foreground hover:text-foreground">Back to top ↑</a>
      </footer>
    </section>
  );
}
