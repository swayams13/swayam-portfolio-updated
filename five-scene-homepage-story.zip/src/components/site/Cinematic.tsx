import { useEffect, useRef, useState } from "react";
import { plates, scenes, type Scene } from "@/lib/content";
import { IntelligenceUI } from "./IntelligenceUI";

/**
 * One continuous, scroll-scrubbed GSAP timeline over a pinned viewport.
 *
 *   factory photo ──(scan wipe)──▶ factory wireframe (same camera)
 *   factory wireframe ──(camera tilt up)──▶ structure wireframe
 *   structure wireframe ──(ground-up mask)──▶ construction photo (same camera)
 *   construction ──(floor-by-floor mask)──▶ completed building (same camera)
 *   completed ──(push into façade + grid)──▶ software interface
 *
 * These are masked reveals between matched 2D plates, not 3D. Real rendered
 * camera moves can replace any plate via `plates.*.video`.
 * Mobile / reduced motion: static stacked scenes (no pinning, no scrub).
 */

// Timeline time at which each scene's copy is fully on screen (drives the HUD).
const SCENE_AT = [0, 2, 4.8, 6.8, 9];
const TOTAL = 10.4;

function Plate({ id, src, video, eager }: { id: string; src: string; video?: string | undefined; eager?: boolean }) {
  return (
    <div data-plate={id} className="absolute inset-0 will-change-transform">
      {video ? (
        <video src={video} poster={src} muted playsInline loop autoPlay className="h-full w-full object-cover" />
      ) : (
        <img
          src={src}
          alt=""
          width={1920}
          height={1088}
          loading={eager ? "eager" : "lazy"}
          fetchPriority={eager ? "high" : "auto"}
          decoding="async"
          className="h-full w-full object-cover"
        />
      )}
    </div>
  );
}

function Copy({ s, i }: { s: Scene; i: number }) {
  return (
    <div data-copy={i} className="absolute inset-x-0 bottom-0 mx-auto grid max-w-[1600px] grid-cols-12 gap-6 px-10 pb-28">
      <div className="col-span-1 self-start pt-[0.6em]">
        <div className="overflow-hidden">
          <span data-line className="display block text-[clamp(1.25rem,1.6vw,1.75rem)] text-copper">
            {s.index}
          </span>
        </div>
      </div>
      <div className="col-span-8">
        <h2 className="display text-[clamp(3rem,6.6vw,7.25rem)]">
          {s.headline.map((l, k) => (
            <span key={l} className="block overflow-hidden pb-[0.04em]">
              <span data-line className={`block ${k === 1 ? "text-steel" : ""}`}>
                {l}
              </span>
            </span>
          ))}
        </h2>
      </div>
      <div className="col-span-3 self-end overflow-hidden pb-[0.2em]">
        <p data-line className="max-w-xs text-[0.95rem] leading-relaxed text-muted-foreground">
          {s.body}
        </p>
      </div>
    </div>
  );
}

export function Cinematic() {
  const root = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let revert: (() => void) | undefined;
    let cancelled = false;
    (async () => {
      const { gsap } = await import("gsap");
      const { ScrollTrigger } = await import("gsap/ScrollTrigger");
      if (cancelled || !root.current) return;
      gsap.registerPlugin(ScrollTrigger);
      const mm = gsap.matchMedia();
      mm.add("(min-width: 768px) and (prefers-reduced-motion: no-preference)", () => {
        const q = gsap.utils.selector(root.current);
        const plate = (id: string) => q(`[data-plate="${id}"]`);
        const lines = (i: number) => q(`[data-copy="${i}"] [data-line]`);

        gsap.set(lines(0), { yPercent: 0 });
        [1, 2, 3, 4].forEach((i) => gsap.set(lines(i), { yPercent: 135 }));

        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            trigger: root.current,
            start: "top top",
            end: "bottom bottom",
            scrub: 0.8,
            onUpdate: (st) => {
              const t = st.progress * TOTAL;
              setProgress(st.progress);
              let a = 0;
              SCENE_AT.forEach((at, k) => t >= at - 0.4 && (a = k));
              setActive(a);
            },
          },
        });

        const out = (i: number, at: number) =>
          tl.to(lines(i), { yPercent: -135, duration: 0.5, stagger: 0.06, ease: "power2.in" }, at);
        const inn = (i: number, at: number) =>
          tl.to(lines(i), { yPercent: 0, duration: 0.6, stagger: 0.08, ease: "power3.out" }, at);

        // Camera: slow dolly down the aisle for the whole factory passage.
        tl.fromTo([plate("factory"), plate("factoryWire")], { scale: 1.02 }, { scale: 1.28, duration: 3.2 }, 0);

        // 01 → 02: scan wipe from photo to linework of the same view.
        out(0, 0.6);
        tl.fromTo(plate("factoryWire"), { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", duration: 1.1, ease: "power1.inOut" }, 1);
        tl.fromTo(q("[data-scan]"), { xPercent: 0, opacity: 1 }, { left: "100%", duration: 1.1, ease: "power1.inOut" }, 1);
        tl.to(q("[data-scan]"), { opacity: 0, duration: 0.1 }, 2.1);
        inn(1, 1.6);

        // 02 → structural frame: camera tilts up out of the plant into the frame.
        tl.to(plate("factoryWire"), { yPercent: 18, opacity: 0, duration: 1.1, ease: "power2.inOut" }, 2.9);
        tl.fromTo(plate("structureWire"), { yPercent: -14, scale: 1.12, opacity: 0 }, { yPercent: 0, scale: 1.04, opacity: 1, duration: 1.2, ease: "power2.inOut" }, 2.9);

        // Frame → 03: material fills the drawing from the ground up.
        out(1, 3.3);
        tl.fromTo(plate("construction"), { clipPath: "inset(100% 0 0 0)" }, { clipPath: "inset(0% 0 0 0)", duration: 1, ease: "power2.inOut" }, 3.9);
        tl.to([plate("structureWire"), plate("construction")], { yPercent: -3, scale: 1.08, duration: 2.2 }, 4.1);
        inn(2, 4.4);

        // 03 → 04: the same building completes, floor by floor.
        out(2, 5.6);
        tl.fromTo(plate("completed"), { clipPath: "inset(100% 0 0 0)", yPercent: -3, scale: 1.08 }, { clipPath: "inset(0% 0 0 0)", duration: 1, ease: "steps(11)" }, 5.9);
        inn(3, 6.1);
        tl.set([plate("factory"), plate("structureWire"), plate("construction")], { autoAlpha: 0 }, 7);

        // 04 → 05: push into the façade; its grid becomes the interface grid.
        out(3, 7.6);
        tl.to(plate("completed"), { scale: 1.6, xPercent: -4, duration: 1.6, ease: "power2.in" }, 7.5);
        tl.fromTo(q("[data-grid] line"), { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 0.9, stagger: 0.02, ease: "power2.out" }, 7.8);
        tl.to(plate("completed"), { opacity: 0, duration: 0.6 }, 8.5);
        tl.fromTo(q("[data-ui]"), { opacity: 0, scale: 1.08, y: 30 }, { opacity: 1, scale: 1, y: 0, duration: 0.9, ease: "power3.out" }, 8.2);
        tl.to(q("[data-grid]"), { opacity: 0.25, duration: 0.6 }, 9.2);
        inn(4, 8.8);
        tl.to({}, { duration: TOTAL - tl.duration() });

        return () => tl.scrollTrigger?.kill();
      });
      revert = () => mm.revert();
    })();
    return () => {
      cancelled = true;
      revert?.();
    };
  }, []);

  return (
    <section aria-label="Industry to intelligence" className="dark bg-charcoal text-foreground">
      {/* ── Desktop cinematic ── */}
      <div ref={root} className="relative hidden h-[700vh] md:motion-safe:block">
        <div className="sticky top-0 h-screen overflow-hidden">
          <Plate id="factory" src={plates.factory.image} video={plates.factory.video} eager />
          <Plate id="factoryWire" src={plates.factoryWire.image} video={plates.factoryWire.video} />
          <div data-scan aria-hidden className="absolute inset-y-0 left-0 w-px bg-copper" style={{ opacity: 0 }} />
          <Plate id="structureWire" src={plates.structureWire.image} video={plates.structureWire.video} />
          <Plate id="construction" src={plates.construction.image} video={plates.construction.video} />
          <Plate id="completed" src={plates.completed.image} video={plates.completed.video} />

          <svg data-grid aria-hidden className="absolute inset-0 h-full w-full" preserveAspectRatio="none" viewBox="0 0 12 8">
            {Array.from({ length: 13 }).map((_, k) => (
              <line key={`v${k}`} x1={k} y1={0} x2={k} y2={8} pathLength={1} strokeDasharray={1} strokeDashoffset={1} className="stroke-steel/40" strokeWidth={0.006} />
            ))}
            {Array.from({ length: 9 }).map((_, k) => (
              <line key={`h${k}`} x1={0} y1={k} x2={12} y2={k} pathLength={1} strokeDasharray={1} strokeDashoffset={1} className="stroke-steel/40" strokeWidth={0.006} />
            ))}
          </svg>

          <div data-ui className="absolute inset-0 flex items-start justify-end px-10 pt-28 opacity-0">
            <div className="w-[56%] max-w-[920px]">
              <IntelligenceUI />
            </div>
          </div>

          {/* Light grade: vignette + bottom falloff for type, no decorative overlays */}
          <div aria-hidden className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,transparent_40%,var(--charcoal)_130%)]" />
          <div aria-hidden className="pointer-events-none absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-charcoal via-charcoal/70 to-transparent" />

          {scenes.map((s, i) => (
            <Copy key={s.id} s={s} i={i} />
          ))}

          {/* HUD: a single hairline of progress and the current chapter */}
          <div className="absolute inset-x-0 bottom-0 mx-auto flex max-w-[1600px] items-center gap-8 px-10 pb-9">
            <span className="label w-40 text-paper">
              {scenes[active]?.index} / {scenes[active]?.label}
            </span>
            <div className="relative h-px flex-1 bg-line-dark" aria-hidden>
              <div className="absolute inset-y-0 left-0 bg-copper" style={{ width: `${progress * 100}%` }} />
              {SCENE_AT.map((at) => (
                <span key={at} className="absolute top-1/2 h-2 w-px -translate-y-1/2 bg-steel/60" style={{ left: `${(at / TOTAL) * 100}%` }} />
              ))}
            </div>
            <a href="#work" className="label text-steel transition-colors hover:text-paper">
              {active === 0 ? "Scroll — or skip to work ↓" : "Skip to work ↓"}
            </a>
          </div>
        </div>
      </div>

      {/* ── Mobile / reduced-motion: static chapters ── */}
      <div className="md:motion-safe:hidden">
        {scenes.map((s, i) => (
          <div key={s.id} className="relative flex min-h-svh items-end overflow-hidden">
            {s.image ? (
              <img src={s.image} alt="" width={1920} height={1088} loading={i === 0 ? "eager" : "lazy"} className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <div className="absolute inset-x-6 top-24">
                <IntelligenceUI />
              </div>
            )}
            <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/60 to-transparent" />
            <div className="relative px-6 pb-16">
              <p className="label text-copper">
                {s.index} — {s.label}
              </p>
              <h2 className="display mt-4 text-[clamp(2.5rem,11vw,4.5rem)]">
                {s.headline[0]} <span className="text-steel">{s.headline[1]}</span>
              </h2>
              <p className="mt-4 max-w-sm text-sm text-muted-foreground">{s.body}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
