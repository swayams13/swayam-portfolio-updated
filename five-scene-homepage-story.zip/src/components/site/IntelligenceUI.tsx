/** Illustrative enterprise interface for scene 05. Data is sample data and labeled as such. */
const rows = [
  { id: "PRJ-A", name: "Pressure vessel package", stage: 3 },
  { id: "PRJ-B", name: "Structural steel — Bay 2", stage: 4 },
  { id: "PRJ-C", name: "Piping skid assembly", stage: 1 },
  { id: "PRJ-D", name: "Heat exchanger set", stage: 2 },
];
const stages = ["Engineering", "Procurement", "Fabrication", "QC", "Dispatch"];

export function IntelligenceUI() {
  return (
    <div className="dark w-full max-w-[1100px] border border-border bg-graphite text-foreground shadow-2xl">
      <div className="flex items-center justify-between border-b border-border px-5 py-3">
        <div className="flex items-center gap-6">
          <span className="label text-copper">Production / Overview</span>
          <span className="label hidden text-muted-foreground sm:inline">Engineering · Documents · Projects</span>
        </div>
        <span className="label border border-copper/50 px-2 py-0.5 text-copper">Illustrative data</span>
      </div>
      <div className="grid grid-cols-12">
        <aside className="col-span-3 hidden border-r border-border p-5 md:block">
          {["Projects", "BOM", "Stages", "Documents", "Reports"].map((l, i) => (
            <p key={l} className={`label py-2 ${i === 0 ? "text-foreground" : "text-muted-foreground"}`}>
              {l}
            </p>
          ))}
        </aside>
        <div className="col-span-12 p-5 md:col-span-9">
          <div className="mb-3 grid grid-cols-[80px_1fr_repeat(5,minmax(0,1fr))] gap-2 text-muted-foreground">
            <span className="label">ID</span>
            <span className="label">Package</span>
            {stages.map((s) => (
              <span key={s} className="label hidden truncate sm:block">
                {s}
              </span>
            ))}
          </div>
          {rows.map((r) => (
            <div
              key={r.id}
              className="grid grid-cols-[80px_1fr_repeat(5,minmax(0,1fr))] items-center gap-2 border-t border-border py-3"
            >
              <span className="font-mono text-xs text-muted-foreground">{r.id}</span>
              <span className="truncate text-sm">{r.name}</span>
              {stages.map((s, i) => (
                <span
                  key={s}
                  className={`hidden h-1.5 sm:block ${i < r.stage ? "bg-steel" : i === r.stage ? "bg-copper" : "bg-secondary"}`}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
