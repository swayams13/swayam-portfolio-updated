import { Link } from "@tanstack/react-router";

const items = [
  { href: "#work", label: "Work" },
  { href: "#expertise", label: "Expertise" },
  { href: "#about", label: "About" },
  { href: "#contact", label: "Contact" },
];

export function Nav() {
  return (
    <header
      className="fixed inset-x-0 top-0 z-50 text-paper mix-blend-difference"
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex max-w-[1600px] items-center justify-between px-6 py-5 md:px-10"
      >
        <Link to="/" className="label font-medium tracking-[0.22em]">
          Swayam Singh
        </Link>
        <ul className="hidden gap-8 md:flex">
          {items.map((i) => (
            <li key={i.href}>
              <a href={`/${i.href}`} className="label opacity-80 transition-opacity hover:opacity-100">
                {i.label}
              </a>
            </li>
          ))}
        </ul>
        <a href="/#contact" className="label border-b border-current pb-1 transition-opacity hover:opacity-70">
          Let's talk ↗
        </a>
      </nav>
    </header>
  );
}
