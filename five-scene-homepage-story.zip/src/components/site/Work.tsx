import { flagships } from "@/lib/content";
import { MOS } from "./work/MOS";
import { Production } from "./work/Production";
import { Engineering } from "./work/Engineering";
import { Tender } from "./work/Tender";
import { BOQ } from "./work/BOQ";
import { Specialized } from "./work/Specialized";
import { Research } from "./work/Research";

export { StatusTag } from "./work/shared";

/** Featured Work: five flagship exhibitions, a specialized index, and research. */
export function Work() {
  return (
    <>
      <section id="work" aria-labelledby="work-h" className="bg-background">
        <div className="mx-auto max-w-[1600px] px-6 pt-36 pb-24 md:px-10">
          <p className="label text-muted-foreground">Featured work · 2024 — 2026</p>
          <h2 id="work-h" className="display mt-8 text-[clamp(4rem,13vw,14rem)]">Selected<br />systems.</h2>
          <div className="mt-12 grid gap-10 md:grid-cols-12">
            <p className="text-xl leading-relaxed md:col-span-5">
              Software platforms, engineering tools, and intelligent workflows designed to solve complex operational challenges.
            </p>
            <ol className="md:col-span-6 md:col-start-7">
              {flagships.map((p) => (
                <li key={p.slug}>
                  <a href={`#${p.slug}`} className="group grid grid-cols-[3rem_1fr_auto] items-baseline gap-4 border-b border-border py-3 transition-colors hover:text-copper">
                    <span className="label text-muted-foreground">{p.number}</span>
                    <span className="text-lg">{p.title}</span>
                    <span className="label text-muted-foreground group-hover:text-copper">{p.status.join(" / ")}</span>
                  </a>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>
      <MOS />
      <Production />
      <Engineering />
      <Tender />
      <BOQ />
      <Specialized />
      <Research />
    </>
  );
}
