import { useState } from "react";
import { bySlug } from "@/lib/content";
import { Capabilities, Ctas, Meta, Sample } from "./shared";

type Line = { no: string; desc: string; unit: string; qty: string; flag?: string };
const LINES: Line[] = [
  { no: "2.01", desc: "Excavation in ordinary soil up to 1.5 m depth", unit: "cum", qty: "1,240" },
  { no: "2.02", desc: "PCC 1:4:8 below footings, 100 mm thick", unit: "m³", qty: "86.5" },
  { no: "2.04", desc: "RCC M30 in slabs, 150 mm thick incl. shuttering", unit: "m³", qty: "", flag: "Missing quantity" },
  { no: "2.07", desc: "TMT reinforcement Fe500D, cutting, bending & placing", unit: "MT", qty: "48.2" },
  { no: "2.11", desc: "RCC M30 in slabs 150mm thk including shuttering", unit: "cum", qty: "312", flag: "Possible duplicate of 2.04" },
  { no: "3.02", desc: "Brick masonry 230 mm in CM 1:6", unit: "sqm", qty: "640", flag: "Unit inconsistent with item type" },
];

const STAGES = ["Original document", "Extracted fields", "Structured table", "Validation", "Review"];

function Original({ marks }: { marks: boolean }) {
  const m = (t: string) => (marks ? <mark className="bg-copper/25 text-inherit">{t}</mark> : t);
  return (
    <div className="bg-paper p-8 font-serif text-[0.85rem] text-charcoal">
      <p className="text-center font-sans text-xs font-semibold tracking-widest uppercase">Bill of Quantities — Part B, Civil Works</p>
      <p className="mt-1 text-center font-sans text-[0.7rem] text-muted-foreground">Sample residential block · illustrative document</p>
      <div className="mt-6 space-y-3">
        {LINES.map((l) => (
          <p key={l.no} className="grid grid-cols-[3rem_1fr_auto] gap-3 border-b border-dotted border-border pb-2">
            <span>{m(l.no)}</span><span>{m(l.desc)}</span>
            <span className="whitespace-nowrap">{m(l.unit)} {l.qty ? m(l.qty) : "____"}</span>
          </p>
        ))}
      </div>
    </div>
  );
}

function Table({ validate, review }: { validate?: boolean; review?: boolean }) {
  return (
    <div className="bg-card p-6">
      <div className="label grid grid-cols-[3.5rem_1fr_4rem_4.5rem_9rem] border-b border-foreground pb-2 text-[0.6rem] text-muted-foreground">
        <span>Item</span><span>Description</span><span>Unit</span><span className="text-right">Qty</span><span className="text-right">{review ? "Reviewer" : validate ? "Check" : "Class"}</span>
      </div>
      {LINES.map((l) => {
        const flagged = (validate || review) && l.flag;
        return (
          <div key={l.no} className={`grid grid-cols-[3.5rem_1fr_4rem_4.5rem_9rem] items-center border-b border-border py-2.5 text-[0.8rem] ${flagged ? "bg-copper/8" : ""}`}>
            <span className="font-mono">{l.no}</span>
            <span className="truncate pr-4">{l.desc}</span>
            <span className="font-mono text-muted-foreground">{l.unit === "cum" ? "m³" : l.unit === "sqm" ? "m²" : l.unit}</span>
            <span className="text-right font-mono">{l.qty || "—"}</span>
            <span className="text-right">
              {review ? (
                flagged ? (
                  <span className="label inline-flex gap-3 text-[0.6rem]"><span className="text-copper">Edit</span><span>Accept</span><span className="text-muted-foreground">Reject</span></span>
                ) : (
                  <span className="label text-[0.6rem] text-muted-foreground">Accepted</span>
                )
              ) : validate ? (
                <span className={`label text-[0.6rem] ${l.flag ? "text-copper" : "text-muted-foreground"}`}>{l.flag ?? "OK"}</span>
              ) : (
                <span className="label text-[0.6rem] text-muted-foreground">{l.no.startsWith("3") ? "Masonry" : l.desc.includes("RCC") ? "Concrete" : l.desc.includes("TMT") ? "Steel" : "Earthwork"}</span>
              )}
            </span>
          </div>
        );
      })}
      {(validate || review) && (
        <p className="label mt-4 text-[0.6rem] text-muted-foreground">
          {review ? "Every flagged line requires a reviewer decision before export." : "3 of 6 lines flagged for review · rule-based checks on sample data"}
        </p>
      )}
    </div>
  );
}

export function BOQ() {
  const p = bySlug("boq-intelligence");
  const [s, setS] = useState(0);
  const view = [<Original key={0} marks={false} />, <Original key={1} marks />, <Table key={2} />, <Table key={3} validate />, <Table key={4} review />][s];

  return (
    <section id={p.slug} aria-labelledby="boq-h" className="bg-secondary">
      <div className="mx-auto max-w-[1600px] px-6 py-32 md:px-10">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          <div className="md:col-span-4">
            <Meta p={p} className="text-muted-foreground" />
            <h3 id="boq-h" className="display mt-10 text-[clamp(3rem,6vw,6.5rem)]">BOQ<br /><span className="font-light">Intelligence</span></h3>
            <p className="mt-6 text-lg leading-relaxed">{p.summary}</p>
            <ol className="mt-12 border-t border-foreground" role="tablist" aria-label="Document workflow">
              {STAGES.map((t, i) => (
                <li key={t}>
                  <button role="tab" aria-selected={s === i} onClick={() => setS(i)} className={`group flex w-full items-baseline justify-between border-b border-border py-4 text-left transition-colors ${s === i ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                    <span className="flex items-baseline gap-5"><span className="label text-copper">{`0${i + 1}`}</span><span className="display text-2xl">{t}</span></span>
                    <span className={`label transition-opacity ${s === i ? "opacity-100" : "opacity-0 group-hover:opacity-60"}`}>●</span>
                  </button>
                </li>
              ))}
            </ol>
            <p className="label mt-4 text-muted-foreground">Select a stage to step through the workflow</p>
          </div>
          <div className="md:col-span-8 md:col-start-5 lg:col-span-7 lg:col-start-6">
            <div className="shadow-[0_40px_80px_-50px_color-mix(in_oklab,var(--charcoal)_60%,transparent)]">
              <div className="flex items-center justify-between bg-card px-5 py-3">
                <span className="label text-[0.6rem] text-muted-foreground">boq / part-b-civil.pdf / {STAGES[s]!.toLowerCase()}</span>
                <Sample>Sample data · no accuracy claimed</Sample>
              </div>
              <div key={s} className="animate-in fade-in slide-in-from-bottom-2 overflow-x-auto duration-500">
                <div className="min-w-[640px]">{view}</div>
              </div>
            </div>
            <div className="mt-6 flex justify-between">
              <button disabled={s === 0} onClick={() => setS(s - 1)} className="label disabled:opacity-30">← Previous</button>
              <button disabled={s === 4} onClick={() => setS(s + 1)} className="label border-b border-current pb-1 disabled:opacity-30">Next stage →</button>
            </div>
          </div>
        </div>
        <div className="mt-24 grid gap-12 border-t border-border pt-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="label text-muted-foreground">Business challenge</p>
            <p className="mt-4 leading-relaxed">{p.problem}</p>
            <p className="label mt-8 text-copper">{p.statusNote}</p>
          </div>
          <div className="md:col-span-8"><Capabilities p={p} /></div>
        </div>
        <Ctas p={p} className="mt-16" />
      </div>
    </section>
  );
}
