import { useRef } from "react";
import { bySlug } from "@/lib/content";
import { useCine } from "@/lib/useCine";
import { Capabilities, Ctas, Meta, Sample } from "./shared";

/** Bellows expansion joint, side elevation. Geometry is generic and illustrative. */
function Drawing() {
  const N = 8, P = 60, X0 = 260;
  let top = `M140,200 L${X0},200`;
  let bot = `M140,400 L${X0},400`;
  for (let i = 0; i < N; i++) {
    const x = X0 + i * P;
    top += ` L${x + 5},200 A25 55 0 0 1 ${x + 55},200 L${x + 60},200`;
    bot += ` L${x + 5},400 A25 55 0 0 0 ${x + 55},400 L${x + 60},400`;
  }
  top += " L860,200";
  bot += " L860,400";
  const arrow = (x: number, y: number, d: number) => `M${x},${y} l${8 * d},-3 v6 z`;
  return (
    <svg viewBox="0 0 1000 620" className="h-auto w-full text-charcoal" role="img" aria-label="Illustrative engineering drawing of a bellows expansion joint">
      <g fill="none" stroke="currentColor" strokeWidth={1.4}>
        <path d={top} /><path d={bot} />
        <rect x={100} y={150} width={40} height={300} /><rect x={860} y={150} width={40} height={300} />
        <path d="M60,200 H100 M60,400 H100 M900,200 H940 M900,400 H940" strokeWidth={1} />
        {/* tie rods */}
        <path d="M90,95 H910 M90,505 H910" strokeWidth={1} />
        {[90, 900].map((x) => <g key={x}><rect x={x - 6} y={86} width={16} height={18} /><rect x={x - 6} y={496} width={16} height={18} /></g>)}
        <path d="M120,104 V150 M880,104 V150 M120,450 V496 M880,450 V496" strokeWidth={1} />
      </g>
      {/* centreline */}
      <path d="M40,300 H960" stroke="currentColor" strokeWidth={0.6} strokeDasharray="22 5 3 5" opacity={0.6} />
      {/* hatching on flanges */}
      <g stroke="currentColor" strokeWidth={0.5} opacity={0.5}>
        {Array.from({ length: 14 }).map((_, i) => <path key={i} d={`M100,${160 + i * 20} l40,-14 M860,${160 + i * 20} l40,-14`} />)}
      </g>
      {/* dimensions */}
      <g className="text-steel" fill="currentColor" stroke="currentColor" fontFamily="var(--font-mono)" fontSize={13} letterSpacing="0.08em">
        <g data-dim="oal">
          <path d="M100,560 H900 M100,545 V575 M900,545 V575" strokeWidth={0.8} fill="none" />
          <path d={arrow(100, 560, 1)} stroke="none" /><path d={arrow(900, 560, -1)} stroke="none" />
          <text x={500} y={552} textAnchor="middle" stroke="none">OAL 800</text>
        </g>
        <g data-dim="id">
          <path d="M40,200 V400 M30,200 H60 M30,400 H60" strokeWidth={0.8} fill="none" />
          <text x={34} y={305} textAnchor="middle" stroke="none" transform="rotate(-90 34 305)">ID 500</text>
        </g>
        <g data-dim="pitch">
          <path d={`M${X0},128 H${X0 + P} M${X0},120 V136 M${X0 + P},120 V136`} strokeWidth={0.8} fill="none" />
          <text x={X0 + P / 2} y={118} textAnchor="middle" stroke="none">q 60</text>
        </g>
        <g data-dim="height">
          <path d="M780,145 V200 M770,145 H790" strokeWidth={0.8} fill="none" />
          <text x={796} y={178} stroke="none">w 55</text>
        </g>
      </g>
      {/* title block */}
      <g fontFamily="var(--font-mono)" fontSize={11} letterSpacing="0.1em" fill="currentColor">
        <rect x={640} y={590} width={360} height={30} fill="none" stroke="currentColor" strokeWidth={1} />
        <text x={652} y={609}>DRG SAMPLE-EJ-014 · REV B · ILLUSTRATIVE</text>
      </g>
    </svg>
  );
}

const kv = "flex items-baseline justify-between gap-6 border-b border-border py-2.5 text-sm";

const PANELS = [
  {
    t: "Engineering parameters",
    dim: "id",
    body: (
      <>
        {[["Nominal size", "DN 500"], ["Design pressure", "10 barg"], ["Design temperature", "350 °C"], ["Axial movement", "± 25 mm"], ["Bellows material", "SS 321"], ["Convolutions", "8"]].map(([k, v]) => (
          <div key={k} className={kv}><span className="text-muted-foreground">{k}</span><span className="font-mono">{v}</span></div>
        ))}
      </>
    ),
  },
  {
    t: "Calculation results",
    dim: "pitch",
    body: (
      <>
        {[["Circumferential membrane stress", "Within allowable"], ["Meridional bending stress", "Within allowable"], ["Instability — column squirm", "Check passed"], ["Fatigue life (design cycles)", "Check passed"], ["Axial spring rate", "Computed"]].map(([k, v]) => (
          <div key={k} className={kv}><span className="text-muted-foreground">{k}</span><span className="label text-[0.6rem] text-copper">{v}</span></div>
        ))}
      </>
    ),
  },
  {
    t: "Structured BOM",
    dim: "oal",
    body: (
      <>
        <div className="label grid grid-cols-[2rem_1fr_5rem_2.5rem] pb-2 text-[0.6rem] text-muted-foreground"><span>#</span><span>Item</span><span>Material</span><span className="text-right">Qty</span></div>
        {[["Bellows element", "SS 321", 1], ["Weld-end pipe DN500", "CS A106", 2], ["Flange DN500 PN16", "CS A105", 2], ["Tie rod M24", "CS B7", 4], ["Hex nut M24", "2H", 16]].map(([a, b, n], i) => (
          <div key={a as string} className="grid grid-cols-[2rem_1fr_5rem_2.5rem] border-b border-border py-2.5 font-mono text-[0.8rem]">
            <span className="text-muted-foreground">{i + 1}</span><span>{a}</span><span className="text-muted-foreground">{b}</span><span className="text-right">{n}</span>
          </div>
        ))}
      </>
    ),
  },
  {
    t: "Costing & documentation",
    dim: "height",
    body: (
      <>
        {["Material cost", "Fabrication", "Testing & inspection", "Packing"].map((k) => (
          <div key={k} className={kv}><span className="text-muted-foreground">{k}</span><span className="font-mono">₹ ——</span></div>
        ))}
        <p className="label mt-6 text-[0.6rem] text-muted-foreground">Generated outputs</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {["Calculation report.pdf", "BOM.xlsx", "Datasheet.pdf", "Cost sheet.xlsx"].map((f) => <span key={f} className="border border-border px-2.5 py-1.5 font-mono text-[0.7rem]">{f}</span>)}
        </div>
      </>
    ),
  },
];

export function Engineering() {
  const p = bySlug("engineering-automation");
  const root = useRef<HTMLElement>(null);

  useCine(root, ({ gsap, q }) => {
    const panels = q("[data-panel]");
    gsap.set(panels, { yPercent: 40, autoAlpha: 0 });
    const tl = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: { trigger: q("[data-track]")[0] as Element, start: "top top", end: "bottom bottom", scrub: 0.6 },
    });
    tl.fromTo(q("[data-drawing]"), { scale: 1.18, xPercent: 18 }, { scale: 1, xPercent: 0, duration: 1, ease: "power2.inOut" }, 0);
    tl.to(q("[data-rail]"), { autoAlpha: 1, duration: 0.3 }, 0.7);
    PANELS.forEach((pn, i) => {
      const at = 1 + i * 1.2;
      if (i > 0) tl.to(panels[i - 1]!, { yPercent: -30, autoAlpha: 0, duration: 0.5, ease: "power2.in" }, at - 0.2);
      tl.to(panels[i]!, { yPercent: 0, autoAlpha: 1, duration: 0.5, ease: "power2.out" }, at);
      tl.to(q("[data-dim]"), { color: "var(--steel)", duration: 0.2 }, at);
      tl.to(q(`[data-dim="${pn.dim}"]`), { color: "var(--copper)", duration: 0.2 }, at);
      tl.to(q("[data-step]"), { opacity: 0.3, duration: 0.2 }, at);
      tl.to(q(`[data-step="${i}"]`), { opacity: 1, duration: 0.2 }, at);
    });
    tl.to({}, { duration: 0.8 });
  });

  return (
    <section ref={root} id={p.slug} aria-labelledby="eng-h" className="bg-card drafting-grid">
      <div className="mx-auto max-w-[1600px] px-6 pt-32 pb-12 md:px-10">
        <Meta p={p} className="text-muted-foreground" />
        <div className="mt-10 grid gap-8 md:grid-cols-12">
          <h3 id="eng-h" className="font-display text-[clamp(3rem,6.5vw,7rem)] font-light uppercase leading-[0.9] tracking-[0.01em] md:col-span-8">
            Engineering<br /><span className="font-extrabold">Automation Suite</span>
          </h3>
          <p className="self-end text-lg leading-relaxed md:col-span-4">{p.summary}</p>
        </div>
      </div>

      <div data-track className="relative cine:h-[600vh]">
        <div className="mx-auto max-w-[1600px] px-6 md:px-10 cine:sticky cine:top-0 cine:flex cine:h-screen cine:items-center">
          <div className="grid w-full gap-10 md:grid-cols-12 md:items-center">
            <div className="md:col-span-7">
              <div data-drawing className="origin-left border border-border bg-card p-4 md:p-8">
                <Drawing />
              </div>
              <p className="label mt-3 text-muted-foreground">Fig. 1 — Bellows expansion joint, side elevation. Illustrative drawing, sample values.</p>
            </div>
            <div className="md:col-span-5">
              <ol data-rail className="label mb-6 flex flex-wrap gap-x-4 gap-y-2 text-[0.6rem] cine:opacity-0">
                {["Drawing", ...PANELS.map((x) => x.t)].map((s, i) => (
                  <li key={s} data-step={i - 1} className="flex items-center gap-4">{s}{i < PANELS.length && <span className="text-copper">→</span>}</li>
                ))}
              </ol>
              <div className="relative space-y-12 cine:min-h-[24rem] cine:space-y-0">
                {PANELS.map((pn, i) => (
                  <div key={pn.t} data-panel className="bg-card cine:absolute cine:inset-x-0 cine:top-0">
                    <div className="mb-4 flex items-baseline justify-between">
                      <p className="display text-3xl">{`0${i + 2}`} <span className="font-light">{pn.t}</span></p>
                      <Sample />
                    </div>
                    {pn.body}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 pt-16 pb-32 md:px-10">
        <div className="grid gap-12 border-t border-border pt-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="label text-muted-foreground">Business challenge</p>
            <p className="mt-4 leading-relaxed">{p.problem}</p>
            <p className="label mt-8 text-copper">{p.statusNote}</p>
          </div>
          <div className="md:col-span-8"><Capabilities p={p} /></div>
        </div>
        <Ctas p={p} className="mt-16" />
      </div>
    </section>
  );
}
