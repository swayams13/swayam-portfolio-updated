import { useRef } from "react";
import { bySlug } from "@/lib/content";
import { useCine } from "@/lib/useCine";
import { Bar, Capabilities, Ctas, Meta, Sample } from "./shared";

/* Module rectangles in a 1600×900 canvas — shared by the layout and the flow lines. */
const MODS = {
  projects: { x: 0, y: 56, w: 500, h: 434, t: "Projects" },
  production: { x: 500, y: 56, w: 720, h: 434, t: "Production" },
  management: { x: 1220, y: 56, w: 380, h: 434, t: "Management" },
  engineering: { x: 0, y: 490, w: 420, h: 410, t: "Engineering" },
  procurement: { x: 420, y: 490, w: 400, h: 410, t: "Procurement" },
  quality: { x: 820, y: 490, w: 400, h: 410, t: "Quality" },
  workforce: { x: 1220, y: 490, w: 380, h: 410, t: "Workforce" },
} as const;
type ModId = keyof typeof MODS;
const pct = (m: (typeof MODS)[ModId]) => ({
  left: `${(m.x / 1600) * 100}%`,
  top: `${(m.y / 900) * 100}%`,
  width: `${(m.w / 1600) * 100}%`,
  height: `${(m.h / 900) * 100}%`,
});
const c = (id: ModId) => [MODS[id].x + MODS[id].w / 2, MODS[id].y + MODS[id].h / 2] as const;

const FOCUS: { id: ModId; head: string; body: string }[] = [
  { id: "engineering", head: "Engineering releases the data.", body: "Drawings, revisions, and BOMs become the shared source every other department works from." },
  { id: "procurement", head: "Procurement sees what to buy.", body: "Material requirements arrive from the released BOM, not from a forwarded spreadsheet." },
  { id: "production", head: "Production runs the stages.", body: "Each job moves through fabrication stages with clear ownership and a current position." },
  { id: "quality", head: "Quality holds the line.", body: "Inspection points sit inside the workflow, so a stage closes only when its checks do." },
  { id: "management", head: "Management sees one picture.", body: "Status is assembled from departmental work as it happens, instead of being chased." },
];

const LINKS: [ModId, ModId, string, number?][] = [
  ["projects", "engineering", "Job created"],
  ["engineering", "procurement", "BOM rev B released"],
  ["procurement", "production", "Material received"],
  ["production", "quality", "Stage ready for inspection"],
  ["quality", "management", "ITP signed off"],
  ["workforce", "production", "Crew allocated", 0.22],
];

function Module({ id, children }: { id: ModId; children: React.ReactNode }) {
  return (
    <div data-mod={id} className="absolute flex flex-col border border-line-dark p-[1.1%]" style={pct(MODS[id])}>
      <div className="mb-[3%] flex items-baseline justify-between">
        <span className="label text-[0.6rem] text-paper">{MODS[id].t}</span>
        <span className="label text-[0.55rem] text-steel">{id.slice(0, 3)}.view</span>
      </div>
      <div className="min-h-0 flex-1 overflow-hidden text-[0.68rem] leading-snug">{children}</div>
    </div>
  );
}

const row = "flex items-center justify-between gap-3 border-b border-line-dark py-[0.45em]";

function Dashboard() {
  return (
    <div data-dash className="relative aspect-[16/9] w-full bg-graphite text-steel">
      {/* top strip */}
      <div className="absolute inset-x-0 top-0 flex h-[6.2%] items-center justify-between border-b border-line-dark px-[1.2%]">
        <span className="label text-[0.6rem] text-paper">MOS <span className="text-steel">/ Sample Industries Pvt. Ltd. / Plant 01</span></span>
        <span className="label hidden text-[0.55rem] sm:block">Projects · Engineering · Procurement · Production · Quality · Workforce · Management</span>
        <Sample />
      </div>
      <Module id="projects">
        {["J-2401 Heat exchanger", "J-2402 Pressure vessel", "J-2403 Expansion joint ×6", "J-2404 Piping skid", "J-2405 Storage tank"].map((j, i) => (
          <div key={j} className={row}>
            <span className="truncate text-paper">{j}</span>
            <span className="w-16 shrink-0"><Bar v={[78, 52, 34, 90, 12][i]!} accent={i === 1} /></span>
          </div>
        ))}
      </Module>
      <Module id="production">
        <div className="grid h-full grid-rows-[auto_1fr]">
          <div className="grid grid-cols-[5.5rem_repeat(6,1fr)] pb-1 text-[0.55rem] uppercase tracking-widest">
            <span />
            {["Cut", "Roll", "Weld", "NDT", "Hydro", "Paint"].map((s) => <span key={s}>{s}</span>)}
          </div>
          <div className="space-y-[0.55em]">
            {[[0, 4], [0, 3], [1, 2], [2, 6], [0, 1]].map(([a, b], i) => (
              <div key={i} className="grid grid-cols-[5.5rem_repeat(6,1fr)] items-center">
                <span className="text-paper">J-240{i + 1}</span>
                {Array.from({ length: 6 }).map((_, k) => (
                  <span key={k} className={`mx-px h-[0.6em] ${k >= a! && k < b! ? (k === b! - 1 ? "bg-copper" : "bg-steel/70") : "bg-paper/5"}`} />
                ))}
              </div>
            ))}
          </div>
        </div>
      </Module>
      <Module id="management">
        {[["Jobs in production", "5"], ["Awaiting material", "1"], ["Inspections due", "2"], ["Docs pending approval", "3"]].map(([k, v]) => (
          <div key={k} className={row}><span>{k}</span><span className="display text-xl text-paper">{v}</span></div>
        ))}
      </Module>
      <Module id="engineering">
        {[["DRG-EJ-014", "Rev B", "Released"], ["DRG-PV-208", "Rev A", "In review"], ["CALC-EJ-014", "Rev B", "Released"], ["BOM-PV-208", "Rev —", "Draft"]].map(([d, r, s]) => (
          <div key={d} className={row}><span className="font-mono text-paper">{d}</span><span>{r}</span><span className={s === "Released" ? "text-copper" : ""}>{s}</span></div>
        ))}
      </Module>
      <Module id="procurement">
        {[["SS 321 sheet 2mm", "PO raised"], ["Flange DN500 PN16", "Received"], ["Tie rod M24", "RFQ"], ["Gasket set", "Received"]].map(([m, s]) => (
          <div key={m} className={row}><span className="truncate text-paper">{m}</span><span className={s === "Received" ? "text-copper" : ""}>{s}</span></div>
        ))}
      </Module>
      <Module id="quality">
        {[["Material cert review", "✓"], ["Fit-up inspection", "✓"], ["Weld visual / DPT", "Hold"], ["Hydro test witness", "—"]].map(([m, s]) => (
          <div key={m} className={row}><span className="text-paper">{m}</span><span className={s === "Hold" ? "text-copper" : ""}>{s}</span></div>
        ))}
      </Module>
      <Module id="workforce">
        <div className="grid grid-cols-[4rem_repeat(5,1fr)] gap-y-[0.5em] text-[0.55rem]">
          <span />
          {["M", "T", "W", "T", "F"].map((d, i) => <span key={i} className="text-center">{d}</span>)}
          {["Welders", "Fitters", "QC", "Helpers"].map((r, i) => (
            <div key={r} className="contents">
              <span className="text-paper">{r}</span>
              {Array.from({ length: 5 }).map((_, k) => (
                <span key={k} className={`mx-auto size-[0.6em] ${(i + k) % 3 === 0 ? "bg-copper" : "bg-steel/50"}`} />
              ))}
            </div>
          ))}
        </div>
      </Module>
      {/* information flow overlay */}
      <svg data-flows viewBox="0 0 1600 900" preserveAspectRatio="none" className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden>
        {LINKS.map(([a, b], i) => {
          const [x1, y1] = c(a);
          const [x2, y2] = c(b);
          const mx = (x1 + x2) / 2;
          const my = (y1 + y2) / 2;
          return <path key={i} data-flow d={Math.abs(y2 - y1) < 50 ? `M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}` : `M${x1},${y1} C${x1},${my} ${x2},${my} ${x2},${y2}`} pathLength={1} fill="none" className="stroke-copper" strokeWidth={1.5} vectorEffect="non-scaling-stroke" strokeDasharray="1" strokeDashoffset="1" />;
        })}
      </svg>
      {LINKS.map(([a, b, t, k = 0.5]) => {
        const [x1, y1] = c(a);
        const [x2, y2] = c(b);
        return (
          <span key={t} data-flowlabel className="label absolute -translate-x-1/2 -translate-y-1/2 bg-charcoal px-2 py-1 text-[0.55rem] whitespace-nowrap text-copper opacity-0" style={{ left: `${((x1 + (x2 - x1) * k) / 1600) * 100}%`, top: `${((y1 + (y2 - y1) * k) / 900) * 100}%` }}>
            {t}
          </span>
        );
      })}
    </div>
  );
}

const LAYERS = [
  { k: "Interfaces", v: ["Engineering", "Procurement", "Production", "Quality", "Workforce", "Management"] },
  { k: "Services", v: ["Projects & jobs", "Workflow engine", "Document control", "Notifications", "Reporting"] },
  { k: "Platform", v: ["Role-based access", "Multi-organization tenancy", "Audit trail"] },
  { k: "Data & integration", v: ["Relational data store", "File storage", "CAD / ERP / spreadsheet connectors"] },
];

function Architecture() {
  return (
    <div className="w-full">
      <div className="mb-6 flex items-baseline justify-between">
        <p className="label text-paper">Simplified system architecture</p>
        <p className="label text-steel">Target architecture — partly planned</p>
      </div>
      <div className="divide-y divide-line-dark border-y border-line-dark">
        {LAYERS.map((l) => (
          <div key={l.k} data-layer className="grid grid-cols-12 items-center gap-4 py-5">
            <span className="label col-span-12 text-copper md:col-span-3">{l.k}</span>
            <div className="col-span-12 flex flex-wrap gap-x-8 gap-y-2 md:col-span-9">
              {l.v.map((x) => <span key={x} className="text-[0.95rem] text-paper">{x}</span>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function MOS() {
  const p = bySlug("manufacturing-operating-system");
  const root = useRef<HTMLElement>(null);

  useCine(root, ({ gsap, q }) => {
    const mods = q("[data-mod]");
    const tl = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: { trigger: q("[data-track]")[0] as Element, start: "top top", end: "bottom bottom", scrub: 0.7 },
    });
    gsap.set(q("[data-focus]"), { autoAlpha: 0, y: 24 });
    gsap.set(q("[data-arch]"), { autoAlpha: 0 });
    gsap.set(q("[data-layer]"), { autoAlpha: 0, y: 20 });
    // 1 intro → dashboard rises out of perspective
    tl.to(q("[data-intro]"), { autoAlpha: 0, y: -60, duration: 1, ease: "power2.in" }, 0.6);
    tl.fromTo(q("[data-stage]"), { rotateX: 32, y: "38vh", scale: 0.78 }, { rotateX: 0, y: 0, scale: 1, duration: 1.6, ease: "power2.out" }, 0.8);
    // 2 department focus: dim the others, slow push toward the active module
    FOCUS.forEach((f, i) => {
      const at = 2.6 + i * 1.1;
      const m = MODS[f.id];
      tl.to(mods, { opacity: 0.18, duration: 0.3 }, at);
      tl.to(q(`[data-mod="${f.id}"]`), { opacity: 1, duration: 0.3 }, at);
      tl.to(q("[data-stage]"), { scale: 1.05, transformOrigin: `${((m.x + m.w / 2) / 1600) * 100}% ${((m.y + m.h / 2) / 900) * 100}%`, duration: 0.6, ease: "power1.inOut" }, at);
      tl.to(q(`[data-focus="${i}"]`), { autoAlpha: 1, y: 0, duration: 0.3 }, at + 0.1);
      tl.to(q(`[data-focus="${i}"]`), { autoAlpha: 0, y: -24, duration: 0.25 }, at + 0.85);
    });
    // 3 information moves between departments
    const flowAt = 2.6 + FOCUS.length * 1.1;
    tl.to(q("[data-stage]"), { scale: 1, transformOrigin: "50% 50%", duration: 0.6, ease: "power2.inOut" }, flowAt);
    tl.to(mods, { opacity: 0.5, duration: 0.4 }, flowAt);
    tl.to(q("[data-flow]"), { strokeDashoffset: 0, duration: 0.5, stagger: 0.2 }, flowAt + 0.3);
    tl.to(q("[data-flowlabel]"), { opacity: 1, duration: 0.2, stagger: 0.2 }, flowAt + 0.5);
    tl.to(q("[data-flowcap]"), { autoAlpha: 1, duration: 0.3 }, flowAt + 0.3);
    // 4 resolve into the architecture
    const archAt = flowAt + 2.2;
    tl.to(q("[data-flowcap]"), { autoAlpha: 0, duration: 0.3 }, archAt);
    tl.to(q("[data-stage]"), { scale: 0.86, rotateX: 18, y: "-8vh", autoAlpha: 0, duration: 1, ease: "power2.in" }, archAt);
    tl.to(q("[data-arch]"), { autoAlpha: 1, duration: 0.3 }, archAt + 0.6);
    tl.to(q("[data-layer]"), { autoAlpha: 1, y: 0, duration: 0.4, stagger: 0.15 }, archAt + 0.7);
    tl.to({}, { duration: 0.6 });
  });

  return (
    <section ref={root} id={p.slug} aria-labelledby="mos-h" className="dark relative bg-charcoal text-foreground">
      <div data-track className="relative cine:h-[900vh]">
        <div className="relative overflow-hidden cine:sticky cine:top-0 cine:h-screen">
          {/* Intro */}
          <div data-intro className="mx-auto max-w-[1600px] px-6 pt-28 pb-16 md:px-10 cine:absolute cine:inset-x-0 cine:top-0 cine:pt-[18vh]">
            <Meta p={p} className="text-steel" />
            <h3 id="mos-h" className="mt-10 font-display text-[clamp(7rem,26vw,26rem)] font-extrabold leading-[0.78] tracking-[-0.02em] text-paper">
              MOS<span className="text-copper">.</span>
            </h3>
            <div className="mt-8 grid gap-6 md:grid-cols-12">
              <p className="display text-3xl text-paper md:col-span-5 md:text-4xl">Manufacturing<br />Operating System</p>
              <p className="max-w-md text-lg leading-relaxed text-muted-foreground md:col-span-5 md:col-start-8">{p.summary}</p>
            </div>
          </div>

          {/* Dashboard stage */}
          <div className="px-6 pb-10 md:px-10 cine:absolute cine:inset-0 cine:flex cine:items-center cine:justify-center cine:p-0 cine:[perspective:1800px]">
            <div className="overflow-x-auto cine:overflow-visible">
              <div data-stage className="min-w-[860px] cine:w-[min(90vw,148vh)] cine:min-w-0">
                <Dashboard />
              </div>
            </div>
          </div>

          {/* Department captions */}
          <div className="hidden cine:block">
            {FOCUS.map((f, i) => (
              <div key={f.id} data-focus={i} className="absolute bottom-[6vh] left-10 max-w-md bg-charcoal/90 p-6">
                <p className="label text-copper">0{i + 1} — {MODS[f.id].t}</p>
                <p className="display mt-3 text-3xl text-paper">{f.head}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </div>
            ))}
            <div data-flowcap className="invisible absolute bottom-[6vh] left-10 max-w-md bg-charcoal/90 p-6">
              <p className="label text-copper">Connected record</p>
              <p className="display mt-3 text-3xl text-paper">One job. Every department.</p>
            </div>
          </div>

          {/* Architecture */}
          <div data-arch className="mx-auto max-w-[1200px] px-6 py-16 md:px-10 cine:absolute cine:inset-0 cine:flex cine:items-center">
            <Architecture />
          </div>
        </div>
      </div>

      {/* Static detail */}
      <div className="mx-auto max-w-[1600px] border-t border-line-dark px-6 py-24 md:px-10">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="label text-steel">Business challenge</p>
            <p className="mt-4 leading-relaxed text-muted-foreground">{p.problem}</p>
            <p className="label mt-10 text-steel">Solution vision</p>
            <p className="mt-4 leading-relaxed text-paper">{p.approach}</p>
            <p className="label mt-10 text-copper">{p.statusNote}</p>
          </div>
          <div className="md:col-span-7 md:col-start-6">
            <Capabilities p={p} cols={2} />
          </div>
        </div>
        <Ctas p={p} className="mt-16 text-paper" />
      </div>
    </section>
  );
}
