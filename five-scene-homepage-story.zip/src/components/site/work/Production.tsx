import { useEffect, useRef, useState } from "react";
import { bySlug } from "@/lib/content";
import { Bar, Capabilities, Ctas, Frame, Meta } from "./shared";

const JOBS = ["J-2401 Heat exchanger", "J-2402 Pressure vessel", "J-2403 Expansion joint ×6", "J-2404 Piping skid"];
const STAGES = ["Engineering", "Procurement", "Fabrication", "Quality", "Dispatch"];
const cell = "border-b border-border py-3";

function Overview() {
  return (
    <div className="p-6">
      <div className="label grid grid-cols-[1fr_6rem_6rem] pb-3 text-muted-foreground"><span>Job</span><span>Stage</span><span>Owner</span></div>
      {JOBS.map((j, i) => (
        <div key={j} className={`grid grid-cols-[1fr_6rem_6rem] items-center ${cell}`}>
          <span className="text-sm text-paper">{j}</span>
          <span className="label text-[0.6rem]">{STAGES[[2, 3, 1, 4][i]!]}</span>
          <span className="label text-[0.6rem] text-muted-foreground">{["Fab-A", "QC", "Purch.", "Stores"][i]}</span>
        </div>
      ))}
    </div>
  );
}
function Timeline() {
  return (
    <div className="p-6">
      <div className="label grid grid-cols-[7rem_repeat(5,1fr)] pb-3 text-[0.6rem] text-muted-foreground"><span />{STAGES.map((s) => <span key={s}>{s}</span>)}</div>
      {JOBS.map((j, i) => (
        <div key={j} className="grid grid-cols-[7rem_repeat(5,1fr)] items-center py-3">
          <span className="truncate text-xs text-paper">{j.split(" ")[0]}</span>
          {STAGES.map((_, k) => {
            const at = [2, 3, 1, 4][i]!;
            return <span key={k} className={`mx-0.5 h-2 ${k < at ? "bg-steel/70" : k === at ? "bg-copper" : "bg-paper/5"}`} />;
          })}
        </div>
      ))}
      <p className="label mt-6 text-[0.6rem] text-muted-foreground">Copper = current stage</p>
    </div>
  );
}
function Department() {
  return (
    <div className="grid grid-cols-3 gap-px bg-border">
      {[["Queued", ["J-2403 Shell rolling", "J-2405 Nozzle prep"]], ["In progress", ["J-2401 Tube bundle", "J-2402 Long seam weld"]], ["Ready for QC", ["J-2402 Shell fit-up"]]].map(([h, items]) => (
        <div key={h as string} className="min-h-72 bg-charcoal p-5">
          <p className="label text-[0.6rem] text-muted-foreground">Fabrication · {h as string}</p>
          <ul className="mt-4 space-y-2">
            {(items as string[]).map((t) => <li key={t} className="border-l border-copper/70 py-1 pl-3 text-xs text-paper">{t}</li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}
function Quality() {
  return (
    <div className="p-6">
      <p className="label text-[0.6rem] text-muted-foreground">J-2402 · Inspection & test plan</p>
      {[["Material certificate review", "Accepted"], ["Fit-up dimensional check", "Accepted"], ["Long seam weld — visual / DPT", "Hold point"], ["Hydrostatic test", "Scheduled"], ["Final documentation", "Pending"]].map(([k, v]) => (
        <div key={k} className={`flex items-center justify-between ${cell}`}>
          <span className="text-sm text-paper">{k}</span>
          <span className={`label text-[0.6rem] ${v === "Hold point" ? "text-copper" : "text-muted-foreground"}`}>{v}</span>
        </div>
      ))}
    </div>
  );
}
function Management() {
  return (
    <div className="grid grid-cols-5 gap-px bg-border">
      {STAGES.map((s, i) => (
        <div key={s} className="bg-charcoal p-5">
          <p className="label text-[0.6rem] text-muted-foreground">{s}</p>
          <p className="display mt-6 text-5xl text-paper">{[1, 1, 2, 1, 0][i]}</p>
          <div className="mt-4"><Bar v={[20, 20, 40, 20, 0][i]!} accent={i === 2} /></div>
        </div>
      ))}
      <p className="label col-span-5 bg-charcoal p-5 text-[0.6rem] text-muted-foreground">Jobs per stage · sample plant</p>
    </div>
  );
}

const VIEWS = [
  { t: "Project overview", path: "pip / jobs", body: "Every job, its current stage, and who owns the next step — on one screen.", C: Overview },
  { t: "Production timeline", path: "pip / timeline", body: "Stage-by-stage progress shows where work is moving and where it is waiting.", C: Timeline },
  { t: "Department dashboard", path: "pip / fabrication", body: "Each department works from its own queue, fed by the same project record.", C: Department },
  { t: "Quality workflow", path: "pip / quality / J-2402", body: "Inspection points are tracked inside the job instead of in a separate register.", C: Quality },
  { t: "Management overview", path: "pip / overview", body: "A combined view assembled from departmental updates, not separate reports.", C: Management },
];

export function Production() {
  const p = bySlug("production-intelligence");
  const [active, setActive] = useState(0);
  const steps = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setActive(Number((e.target as HTMLElement).dataset["i"]))),
      { rootMargin: "-45% 0px -45% 0px" },
    );
    steps.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <section id={p.slug} aria-labelledby="pip-h" className="bg-background">
      <div className="mx-auto max-w-[1600px] px-6 pt-32 md:px-10">
        <Meta p={p} className="text-muted-foreground" />
        <div className="mt-10 grid gap-8 md:grid-cols-12">
          <h3 id="pip-h" className="display text-[clamp(3.5rem,8vw,8.5rem)] md:col-span-8">
            Production<br /><span className="text-steel">Intelligence.</span>
          </h3>
          <p className="self-end text-lg leading-relaxed md:col-span-4">{p.summary}</p>
        </div>
      </div>

      <div className="mx-auto grid max-w-[1600px] grid-cols-1 gap-10 px-6 pt-20 md:grid-cols-12 md:px-10">
        {/* synced narrative */}
        <div className="min-w-0 md:col-span-4">
          {VIEWS.map((v, i) => (
            <div key={v.t} ref={(el) => { steps.current[i] = el; }} data-i={i} className="flex flex-col justify-center py-10 md:min-h-[80vh] md:py-0">
              <p className={`label transition-colors ${active === i ? "text-copper" : "text-muted-foreground"}`}>0{i + 1} / 05</p>
              <p className={`display mt-4 text-4xl transition-opacity duration-500 md:text-5xl ${active === i ? "opacity-100" : "md:opacity-25"}`}>{v.t}</p>
              <p className={`mt-4 max-w-sm leading-relaxed text-muted-foreground transition-opacity duration-500 ${active === i ? "opacity-100" : "md:opacity-0"}`}>{v.body}</p>
              <div className="mt-8 md:hidden">
                <Frame path={v.path}><div className="overflow-x-auto"><div className="min-w-[540px]"><v.C /></div></div></Frame>
              </div>
            </div>
          ))}
        </div>
        {/* sticky product preview */}
        <div className="hidden md:col-span-8 md:block">
          <div className="sticky top-[14vh]">
            <Frame path={VIEWS[active]!.path}>
              <div className="relative min-h-[22rem]">
                {VIEWS.map((v, i) => (
                  <div key={v.t} aria-hidden={active !== i} className={`absolute inset-0 transition-[opacity,transform] duration-700 ease-out ${active === i ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0"}`}>
                    {p.media.screenshots?.[i] ? <img src={p.media.screenshots[i]} alt={v.t} className="h-full w-full object-cover" /> : <v.C />}
                  </div>
                ))}
              </div>
            </Frame>
            <div className="mt-4 flex gap-1" aria-hidden>
              {VIEWS.map((v, i) => <span key={v.t} className={`h-px flex-1 transition-colors ${i <= active ? "bg-foreground" : "bg-border"}`} />)}
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 pt-24 pb-32 md:px-10">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="label text-muted-foreground">Business challenge</p>
            <p className="mt-4 leading-relaxed">{p.problem}</p>
            <p className="label mt-8 text-copper">{p.statusNote}</p>
          </div>
          <div className="md:col-span-8">
            <Capabilities p={p} />
          </div>
        </div>
        <div className="mt-16 flex aspect-[21/9] items-end justify-between bg-secondary p-6">
          {p.media.video ? (
            <video src={p.media.video} controls className="h-full w-full object-cover" />
          ) : (
            <>
              <p className="label text-muted-foreground">Product walkthrough — video slot, recording pending</p>
              <p className="label text-muted-foreground">≈ 60–90 s</p>
            </>
          )}
        </div>
        <Ctas p={p} className="mt-12" />
      </div>
    </section>
  );
}
