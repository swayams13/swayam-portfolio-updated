import { research } from "@/lib/content";
import { Ctas, StatusTag } from "./shared";

function MethodFigure() {
  const nodes = [
    ["Handwriting samples", "input"],
    ["Handwriting-related features", "extraction"],
    ["Other modalities", "input"],
    ["Multimodal fusion model", "model"],
    ["Research signal", "output"],
  ];
  return (
    <figure>
      <svg viewBox="0 0 640 260" className="h-auto w-full text-charcoal" role="img" aria-label="Research method diagram">
        <g fill="none" stroke="currentColor" strokeWidth={1}>
          <rect x={10} y={30} width={150} height={56} /><rect x={10} y={170} width={150} height={56} />
          <rect x={220} y={30} width={150} height={56} /><rect x={430} y={100} width={150} height={56} />
          <path d="M160,58 H220 M370,58 C400,58 400,128 430,128 M160,198 C300,198 400,198 400,150 L430,140" />
        </g>
        <path d="M580,128 H630" stroke="var(--copper)" strokeWidth={1.4} />
        <g fontFamily="var(--font-mono)" fontSize={10} letterSpacing="0.08em" fill="currentColor">
          <text x={20} y={62}>HANDWRITING</text><text x={20} y={202}>OTHER MODALITIES</text>
          <text x={230} y={62}>FEATURE EXTRACTION</text><text x={440} y={132}>MULTIMODAL FUSION</text>
          <text x={590} y={120} fill="var(--copper)">SIGNAL</text>
        </g>
      </svg>
      <figcaption className="label mt-4 text-[0.6rem] text-muted-foreground">
        Fig. 1 — Simplified research method. {nodes.length} stages; schematic only.
      </figcaption>
    </figure>
  );
}

export function Research() {
  const p = research[0]!;
  return (
    <section id={p.slug} aria-labelledby="res-h" className="border-t border-border bg-card">
      <div className="mx-auto max-w-[1300px] px-6 py-32 md:px-10">
        <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-foreground pb-4">
          <h2 className="label">Research & experimentation.</h2>
          <StatusTag status={p.status} />
        </div>
        <div className="mt-16 grid gap-16 md:grid-cols-12">
          <div className="md:col-span-7">
            <h3 id="res-h" className="font-serif text-[clamp(2.25rem,4vw,3.75rem)] leading-[1.08] tracking-[-0.01em]">
              MedPulse — multimodal AI for physician burnout detection
            </h3>
            <p className="label mt-8 text-muted-foreground">Abstract</p>
            <p className="mt-3 font-serif text-lg leading-relaxed">{p.summary} {p.problem}</p>
            <div className="mt-12"><MethodFigure /></div>
          </div>
          <aside className="space-y-10 md:col-span-4 md:col-start-9">
            <div className="border-t border-foreground pt-4">
              <p className="label text-muted-foreground">Published patent application</p>
              <p className="mt-3 font-mono text-xl">Application No. {p.patent}</p>
            </div>
            <div className="border-t border-border pt-4">
              <p className="label text-muted-foreground">Field</p>
              <p className="mt-3">{p.industry}</p>
            </div>
            <div className="border-t border-border pt-4">
              <p className="label text-copper">Scope & limitations</p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Presented as research. MedPulse is not deployed clinically, and no validated diagnostic effectiveness is claimed.
              </p>
            </div>
            <Ctas p={p} />
          </aside>
        </div>
      </div>
    </section>
  );
}
