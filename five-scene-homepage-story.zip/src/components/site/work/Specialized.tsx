import { Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { specialized } from "@/lib/content";
import { StatusTag } from "./shared";

export function Specialized() {
  const [hover, setHover] = useState<number | null>(null);
  const [y, setY] = useState(0);
  const list = useRef<HTMLOListElement>(null);

  return (
    <section id="expertise" aria-labelledby="spec-h" className="bg-background">
      <div className="mx-auto max-w-[1600px] px-6 py-32 md:px-10">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-12">
          <h2 id="spec-h" className="display text-[clamp(2.75rem,5.5vw,5.5rem)] md:col-span-7">Specialized systems.</h2>
          <p className="self-end leading-relaxed text-muted-foreground md:col-span-4 md:col-start-9">
            Focused engineering tools and operational workflows developed for specific industrial challenges.
          </p>
        </div>
        <div className="relative mt-16">
          <div className="label hidden grid-cols-12 gap-6 pb-3 text-[0.6rem] text-muted-foreground md:grid">
            <span className="col-span-1">No.</span><span className="col-span-4">System</span><span className="col-span-4">Scope</span><span className="col-span-3">Status</span>
          </div>
          <ol
            ref={list}
            className="border-t border-foreground"
            onMouseMove={(e) => list.current && setY(e.clientY - list.current.getBoundingClientRect().top)}
            onMouseLeave={() => setHover(null)}
          >
            {specialized.map((p, i) => (
              <li key={p.slug} onMouseEnter={() => setHover(i)}>
                <Link to="/work/$slug" params={{ slug: p.slug }} className="group grid grid-cols-12 items-baseline gap-x-6 gap-y-2 border-b border-border py-7 transition-colors hover:text-copper">
                  <span className="label col-span-2 text-muted-foreground md:col-span-1">{p.number}</span>
                  <span className="display col-span-10 text-2xl transition-transform duration-500 group-hover:translate-x-2 md:col-span-4 md:text-3xl">{p.title}</span>
                  <span className="col-span-12 text-sm text-muted-foreground md:col-span-4">{p.summary}</span>
                  <span className="col-span-12 flex items-center justify-between text-foreground md:col-span-3">
                    <StatusTag status={p.status} />
                    <span className="label opacity-0 transition-opacity group-hover:opacity-100">↗</span>
                  </span>
                </Link>
              </li>
            ))}
          </ol>
          {/* hover preview follows the cursor vertically, desktop only */}
          <div
            aria-hidden
            className={`pointer-events-none absolute right-[22%] top-0 hidden w-64 transition-opacity duration-300 lg:block ${hover === null ? "opacity-0" : "opacity-100"}`}
            style={{ transform: `translateY(${y - 90}px)` }}
          >
            {specialized.map((p, i) => (
              <img key={p.slug} src={p.media.image} alt="" loading="lazy" className={`absolute inset-x-0 aspect-[4/3] w-full object-cover grayscale transition-opacity duration-300 ${hover === i ? "opacity-100" : "opacity-0"}`} />
            ))}
          </div>
        </div>
        <p className="label mt-6 text-muted-foreground">Preview images are atmospheric, not product screenshots.</p>
      </div>
    </section>
  );
}
