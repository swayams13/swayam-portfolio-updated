import { useRef } from "react";
import { bySlug } from "@/lib/content";
import { useCine } from "@/lib/useCine";
import { Capabilities, Ctas, Meta, Sample } from "./shared";

const STEPS = ["Document", "Structured data", "Engineering review", "Quotation"];

function Hl({ children }: { children: React.ReactNode }) {
  return <mark data-hl className="[box-decoration-break:clone] bg-transparent text-inherit [background-image:linear-gradient(color-mix(in_oklab,var(--copper)_35%,transparent),color-mix(in_oklab,var(--copper)_35%,transparent))] bg-no-repeat [background-size:100%_100%] cine:[background-size:0%_100%]">{children}</mark>;
}

function TenderDoc() {
  return (
    <div className="mx-auto w-full max-w-[34rem] bg-paper p-10 font-serif text-[0.82rem] leading-[1.7] text-charcoal shadow-[0_50px_90px_-40px_black]">
      <p className="label text-[0.6rem] text-muted-foreground">Sample tender — illustrative, not a real enquiry</p>
      <p className="mt-6 text-center font-sans text-sm font-semibold tracking-wide uppercase">Section 4 — Technical Specification</p>
      <p className="mt-1 text-center font-sans text-xs">Supply of Metallic Expansion Joints for Flue Gas Duct</p>
      <p className="mt-6"><b>4.1 Scope.</b> The bidder shall design, manufacture, inspect and supply <Hl>six (6) nos. metallic bellows expansion joints</Hl> for the duct system described in Annexure B.</p>
      <p className="mt-3"><b>4.2 Design basis.</b> Joints shall be suitable for a <Hl>design pressure of 10 barg</Hl> and a <Hl>design temperature of 350 °C</Hl>, with <Hl>axial movement of ±25 mm</Hl>. Design shall follow <Hl>EJMA, latest edition</Hl>.</p>
      <p className="mt-3"><b>4.3 Materials.</b> Bellows shall be <Hl>SS 321</Hl>; end connections <Hl>DN 500 flanged, PN16</Hl>. Material test certificates per EN 10204 3.1.</p>
      <p className="mt-3"><b>4.4 Inspection.</b> <Hl>Hydrostatic test at 1.5× design pressure</Hl>; 100% DPT of longitudinal seams.</p>
      <p className="mt-3"><b>4.5 Delivery.</b> Within <Hl>16 weeks</Hl> from purchase order.</p>
    </div>
  );
}

const SPEC = [["Item", "Metallic bellows expansion joint"], ["Quantity", "6 nos."], ["Size / connection", "DN 500 · flanged PN16"], ["Design pressure", "10 barg"], ["Design temperature", "350 °C"], ["Axial movement", "± 25 mm"], ["Bellows material", "SS 321"], ["Design code", "EJMA"], ["Testing", "Hydro 1.5× DP · DPT 100%"], ["Delivery", "16 weeks"]];

function Structured() {
  return (
    <div className="w-full max-w-[34rem]">
      <div className="mb-4 flex justify-between"><p className="label text-paper">Structured specification</p><Sample /></div>
      {SPEC.map(([k, v]) => (
        <div key={k} data-spec className="grid grid-cols-[11rem_1fr] border-b border-line-dark py-2.5 text-sm">
          <span className="text-muted-foreground">{k}</span><span className="font-mono text-paper">{v}</span>
        </div>
      ))}
      <p className="label mt-4 text-[0.6rem] text-muted-foreground">Each field keeps a link to its source clause (4.1 – 4.5)</p>
    </div>
  );
}

function Review() {
  const rows: [string, string, string][] = [["Design pressure · 10 barg", "§4.2", "Accepted"], ["Design temperature · 350 °C", "§4.2", "Accepted"], ["Axial movement · ±25 mm", "§4.2", "Clarify lateral?"], ["Bellows material · SS 321", "§4.3", "Accepted"], ["Hydro test · 1.5× DP", "§4.4", "Edited → 15 barg"]];
  return (
    <div className="w-full max-w-[34rem]">
      <div className="mb-4 flex justify-between"><p className="label text-paper">Engineering review</p><Sample /></div>
      {rows.map(([k, s, st]) => (
        <div key={k} className="grid grid-cols-[1fr_3rem_8rem] items-center border-b border-line-dark py-3 text-sm">
          <span className="text-paper">{k}</span><span className="label text-[0.6rem] text-muted-foreground">{s}</span>
          <span className={`label text-right text-[0.6rem] ${st === "Accepted" ? "text-muted-foreground" : "text-copper"}`}>{st}</span>
        </div>
      ))}
      <p className="label mt-6 text-[0.6rem] text-muted-foreground">Reviewer: engineering · nothing proceeds without human approval</p>
    </div>
  );
}

function Quote() {
  return (
    <div className="w-full max-w-[34rem] bg-graphite p-8">
      <div className="flex items-baseline justify-between border-b border-line-dark pb-4">
        <p className="display text-2xl text-paper">Quotation <span className="text-steel">Q-SAMPLE-031</span></p>
        <Sample />
      </div>
      {[["Expansion joint DN500, SS321 bellows", "6"], ["Hydrostatic testing & DPT", "1 lot"], ["Documentation & MTCs", "1 lot"]].map(([k, q]) => (
        <div key={k} className="grid grid-cols-[1fr_4rem_6rem] border-b border-line-dark py-3 text-sm">
          <span className="text-paper">{k}</span><span className="font-mono text-muted-foreground">{q}</span><span className="text-right font-mono text-muted-foreground">₹ ——</span>
        </div>
      ))}
      <div className="mt-6 flex items-center justify-between">
        <span className="label text-[0.6rem] text-muted-foreground">Status · Draft — awaiting commercial approval</span>
        <span className="label border-b border-copper pb-1 text-[0.6rem] text-copper">Send for approval</span>
      </div>
    </div>
  );
}

const PANELS = [TenderDoc, Structured, Review, Quote];

export function Tender() {
  const p = bySlug("tender-to-quotation");
  const root = useRef<HTMLElement>(null);

  useCine(root, ({ gsap, q }) => {
    const track = q("[data-htrack]")[0] as HTMLElement;
    const tl = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: { trigger: q("[data-track]")[0] as Element, start: "top top", end: "bottom bottom", scrub: 0.6 },
    });
    tl.to(q("[data-hl]"), { backgroundSize: "100% 100%", duration: 0.12, stagger: 0.09 }, 0.1);
    const pan = () => -(track.scrollWidth - window.innerWidth);
    tl.to(track, { x: pan, duration: 3, ease: "power1.inOut" }, 1.3);
    tl.fromTo(q("[data-spec]"), { autoAlpha: 0, x: -20 }, { autoAlpha: 1, x: 0, stagger: 0.04, duration: 0.2 }, 1.7);
    tl.fromTo(q("[data-progress]"), { scaleX: 0 }, { scaleX: 1, duration: 4.3 }, 0);
    [0, 1.9, 2.9, 3.9].forEach((at, i) => {
      tl.to(q("[data-tstep]"), { opacity: 0.35, duration: 0.1 }, at);
      tl.to(q(`[data-tstep="${i}"]`), { opacity: 1, duration: 0.1 }, at);
    });
    tl.to({}, { duration: 0.5 });
  });

  return (
    <section ref={root} id={p.slug} aria-labelledby="tq-h" className="dark bg-charcoal text-foreground">
      <div className="mx-auto max-w-[1600px] px-6 pt-32 md:px-10">
        <Meta p={p} className="text-steel" />
        <h3 id="tq-h" className="display mt-10 text-[clamp(3rem,7.5vw,8rem)] text-paper">
          Tender <span className="font-light text-copper">→</span> Quotation<br /><span className="text-steel">Intelligence.</span>
        </h3>
        <p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground">{p.summary}</p>
      </div>

      <div data-track className="relative cine:h-[520vh]">
        <div className="overflow-hidden py-16 cine:sticky cine:top-0 cine:flex cine:h-screen cine:flex-col cine:justify-center cine:py-0">
          <div className="mx-auto mb-10 hidden w-full max-w-[1600px] px-10 cine:block">
            <div className="label flex justify-between text-paper">
              {STEPS.map((s, i) => <span key={s} data-tstep={i} className="opacity-35">{`0${i + 1}`} {s}</span>)}
            </div>
            <div className="mt-3 h-px bg-line-dark"><div data-progress className="h-px origin-left bg-copper" /></div>
          </div>
          <div data-htrack className="flex flex-col gap-16 px-6 cine:w-max cine:flex-row cine:items-center cine:gap-0 cine:px-0">
            {PANELS.map((P, i) => (
              <div key={i} className="flex flex-col items-center cine:w-[60vw] cine:shrink-0 cine:first:w-[70vw] cine:first:pl-[10vw]">
                <p className="label mb-6 self-start text-copper cine:hidden">{`0${i + 1}`} {STEPS[i]}</p>
                <P />
              </div>
            ))}
            <div className="hidden cine:block cine:w-[15vw]" />
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 pt-16 pb-32 md:px-10">
        <div className="grid gap-12 border-t border-line-dark pt-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="label text-steel">Business challenge</p>
            <p className="mt-4 leading-relaxed text-muted-foreground">{p.problem}</p>
            <p className="label mt-8 text-copper">{p.statusNote}</p>
          </div>
          <div className="md:col-span-8"><Capabilities p={p} /></div>
        </div>
        <Ctas p={p} className="mt-16 text-paper" />
      </div>
    </section>
  );
}
