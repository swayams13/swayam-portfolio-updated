import s1 from "@/assets/scene-01-manufacturing.jpg";
import s2 from "@/assets/scene-02-engineering.jpg";
import s3 from "@/assets/scene-03-construction.jpg";
import p1w from "@/assets/scene-01b-manufacturing-wire.jpg";
import p3w from "@/assets/scene-03a-structure-wire.jpg";
import p3c from "@/assets/scene-03b-completed.jpg";

/**
 * Cinematic plates, in timeline order. Pairs share an identical camera so masked
 * reveals read as one view transforming. `video` (optional) replaces a still with a
 * rendered camera move later; the timeline targets the wrapper, not the media.
 */
export const plates = {
  factory: { image: s1, video: undefined as string | undefined },
  factoryWire: { image: p1w, video: undefined as string | undefined },
  structureWire: { image: p3w, video: undefined as string | undefined },
  construction: { image: s3, video: undefined as string | undefined },
  completed: { image: p3c, video: undefined as string | undefined },
};

/**
 * Scene manifest. Each scene accepts an image today; `video` can be set later
 * (e.g. a rendered MP4 camera move) and the cinematic component will prefer it.
 */
export type Scene = {
  id: string;
  index: string;
  label: string;
  headline: [string, string];
  body: string;
  image?: string;
  video?: string;
  placeholder: boolean;
};

export const scenes: Scene[] = [
  {
    id: "manufacturing",
    index: "01",
    label: "Manufacturing",
    headline: ["Systems for industries", "that build the world."],
    body: "AI, automation, and custom software for complex industrial operations.",
    image: s1,
    placeholder: true,
  },
  {
    id: "engineering",
    index: "02",
    label: "Engineering",
    headline: ["From complex engineering", "to connected workflows."],
    body: "Engineering automation, technical documentation, BOM generation, and quotation workflows.",
    image: p1w,
    placeholder: true,
  },
  {
    id: "construction",
    index: "03",
    label: "Construction",
    headline: ["Bringing clarity", "to complex projects."],
    body: "Document intelligence, BOQ workflows, project visibility, and operational software.",
    image: s3,
    placeholder: true,
  },
  {
    id: "realestate",
    index: "04",
    label: "Real Estate",
    headline: ["Better information.", "Better decisions."],
    body: "Digital systems for project information, property operations, and business workflows.",
    image: p3c,
    placeholder: true,
  },
  {
    id: "intelligence",
    index: "05",
    label: "Intelligence",
    headline: ["The systems behind", "better operations."],
    body: "Selected software and automation projects designed around real business challenges.",
    placeholder: false,
  },
];

/* ───────────────────────── Projects ─────────────────────────
 * One data model drives the homepage showcases, the specialized index, the research
 * feature, and every /work/$slug page. Replace `media` entries with real screenshots
 * or walkthrough videos; showcases prefer them over the illustrative sample UI.
 */

/** The only status labels allowed on the site. */
export type Status =
  | "Delivered Components"
  | "Active Pilot"
  | "In Development"
  | "Prototype"
  | "Planned"
  | "Research";

/** Per-capability honesty marker. "To verify" = Swayam must confirm before publishing. */
export type CapState = "Implemented" | "In development" | "Planned" | "To verify";

export type Cta = { label: string; hash?: "workflow" | "demo" | "architecture" };

export type Project = {
  slug: string;
  number: string;
  title: string;
  short?: string;
  tier: "flagship" | "specialized" | "research";
  industry: string;
  status: Status[];
  statusNote: string;
  summary: string;
  problem: string;
  approach: string;
  features: { name: string; state: CapState }[];
  flow: string[];
  architecture: string[];
  ctas: [Cta, Cta];
  media: { image?: string; video?: string; screenshots?: string[] };
  patent?: string;
};

export const projects: Project[] = [
  {
    slug: "manufacturing-operating-system",
    number: "01",
    title: "Manufacturing Operating System",
    short: "MOS",
    tier: "flagship",
    industry: "Manufacturing / EPC / Industrial Operations",
    status: ["In Development"],
    statusNote: "Enterprise platform in development. Not deployed or production-ready as a whole.",
    summary:
      "A unified digital operating environment designed to connect departments, engineering information, production activities, and management workflows.",
    problem:
      "Industrial businesses frequently operate through disconnected spreadsheets, departmental systems, manual communication, and fragmented operational records. This makes it difficult to maintain consistent information and coordinate work across departments.",
    approach:
      "A unified Manufacturing Operating System that brings key operational workflows into a connected software environment.",
    features: [
      { name: "Centralized operational dashboard", state: "In development" },
      { name: "Department-specific interfaces", state: "In development" },
      { name: "Project and job management", state: "In development" },
      { name: "Production workflow coordination", state: "In development" },
      { name: "Engineering document management", state: "Planned" },
      { name: "Procurement visibility", state: "Planned" },
      { name: "Quality control workflows", state: "Planned" },
      { name: "Workforce and resource management", state: "Planned" },
      { name: "Management reporting", state: "Planned" },
      { name: "Role-based access", state: "Planned" },
      { name: "Multi-organization architecture", state: "Planned" },
      { name: "Integration with engineering and business systems", state: "Planned" },
    ],
    flow: ["Engineering", "Procurement", "Production", "Quality", "Management"],
    architecture: ["Department interfaces", "Workflow & project services", "Documents & roles", "Multi-org data store", "Integrations"],
    ctas: [{ label: "Explore the platform" }, { label: "View system architecture", hash: "architecture" }],
    media: {},
  },
  {
    slug: "production-intelligence",
    number: "02",
    title: "Production Intelligence Platform",
    tier: "flagship",
    industry: "Manufacturing / Industrial Equipment Production",
    status: ["Active Pilot", "In Development"],
    statusNote: "Active development and pilot. Capability states to be confirmed by Swayam before publishing.",
    summary:
      "A production tracking system designed to connect engineering, procurement, fabrication, quality control, and management workflows.",
    problem:
      "Production progress is often tracked through separate spreadsheets and manual departmental updates. This creates difficulties in understanding job status, identifying bottlenecks, and coordinating activities.",
    approach:
      "A centralized production intelligence platform that organizes project stages, departmental workflows, and operational information.",
    features: [
      { name: "Equipment and job tracking", state: "Implemented" },
      { name: "Production stage monitoring", state: "Implemented" },
      { name: "Department-specific dashboards", state: "Implemented" },
      { name: "BOM-based workflows", state: "Implemented" },
      { name: "Procurement visibility", state: "To verify" },
      { name: "Quality inspection tracking", state: "To verify" },
      { name: "Progress reporting", state: "In development" },
      { name: "Task ownership", state: "To verify" },
      { name: "Operational alerts", state: "Planned" },
    ],
    flow: ["Project overview", "Production timeline", "Department dashboard", "Quality workflow", "Management overview"],
    architecture: ["Web client", "API layer", "Relational database", "Role-based access", "Report exports"],
    ctas: [{ label: "Explore case study" }, { label: "Watch product walkthrough", hash: "demo" }],
    media: { image: s1 },
  },
  {
    slug: "engineering-automation",
    number: "03",
    title: "Engineering Automation Suite",
    tier: "flagship",
    industry: "EPC / Industrial Equipment Engineering",
    status: ["Delivered Components", "In Development"],
    statusNote: "Some calculation and BOM tools delivered; CAD-related capabilities are planned or experimental.",
    summary:
      "Engineering automation tools designed to reduce repetitive calculations, documentation work, and manual engineering processes.",
    problem:
      "Engineering teams frequently repeat calculations, prepare BOMs manually, generate documentation, and transfer information between disconnected tools.",
    approach:
      "A collection of engineering automation workflows covering calculations, structured engineering data, costing, and drawing-related processes.",
    features: [
      { name: "Expansion joint engineering calculations", state: "Implemented" },
      { name: "Pressure vessel design calculations", state: "Implemented" },
      { name: "Engineering BOM generation", state: "Implemented" },
      { name: "Material and cost estimation", state: "Implemented" },
      { name: "Technical document generation", state: "In development" },
      { name: "Engineering data validation", state: "In development" },
      { name: "Drawing-related automation", state: "Planned" },
      { name: "CAD integration workflows", state: "Planned" },
    ],
    flow: ["Engineering drawing", "Parameters", "Calculation results", "Structured BOM", "Costing / documentation"],
    architecture: ["Input templates", "Calculation engine", "BOM schema", "Costing rules", "Document generator"],
    ctas: [{ label: "Explore engineering systems" }, { label: "View workflow demo", hash: "workflow" }],
    media: { image: s2 },
  },
  {
    slug: "tender-to-quotation",
    number: "04",
    title: "Tender-to-Quotation Intelligence",
    tier: "flagship",
    industry: "Manufacturing / EPC / Engineering Sales",
    status: ["Planned", "In Development"],
    statusNote: "Planned / in development. Verify scope with Swayam before publication.",
    summary:
      "A document-driven workflow designed to streamline the journey from incoming tender information to structured engineering and commercial outputs.",
    problem:
      "Tender documents often contain large amounts of technical information that must be reviewed, extracted, validated, and transferred into engineering and quotation workflows.",
    approach:
      "An intelligent document processing system designed to organize tender information and support engineering quotation preparation.",
    features: [
      { name: "Tender document ingestion", state: "To verify" },
      { name: "Technical requirement extraction", state: "To verify" },
      { name: "Structured specification generation", state: "Planned" },
      { name: "Engineering parameter identification", state: "Planned" },
      { name: "BOM preparation support", state: "Planned" },
      { name: "Cost estimation workflows", state: "Planned" },
      { name: "Quotation document generation", state: "Planned" },
      { name: "Human review and approval", state: "Planned" },
      { name: "Engineering document traceability", state: "Planned" },
    ],
    flow: ["Document", "Structured data", "Engineering review", "Quotation"],
    architecture: ["Document ingest", "Extraction model", "Specification schema", "Review & approval", "Quotation generator"],
    ctas: [{ label: "Explore workflow", hash: "workflow" }, { label: "View system concept", hash: "architecture" }],
    media: {},
  },
  {
    slug: "boq-intelligence",
    number: "05",
    title: "BOQ Intelligence Platform",
    tier: "flagship",
    industry: "Construction / Real Estate Development",
    status: ["Prototype", "In Development"],
    statusNote: "Prototype. No accuracy figures are claimed; all data shown is sample data.",
    summary:
      "An AI-assisted construction document intelligence system focused on BOQ extraction, validation, and structured estimation workflows.",
    problem:
      "Construction estimation teams often work with lengthy BOQ documents, spreadsheets, and inconsistent document formats. Manual extraction and review can be repetitive and error-prone.",
    approach: "A system that converts construction BOQ information into structured, reviewable data.",
    features: [
      { name: "PDF and spreadsheet ingestion", state: "In development" },
      { name: "BOQ line-item extraction", state: "In development" },
      { name: "Unit and quantity identification", state: "In development" },
      { name: "Structured item classification", state: "Planned" },
      { name: "Duplicate and inconsistency detection", state: "Planned" },
      { name: "Quantity validation support", state: "Planned" },
      { name: "Human review interface", state: "Planned" },
      { name: "Exportable structured BOQ", state: "Planned" },
    ],
    flow: ["Original BOQ", "Extracted fields", "Structured table", "Validation", "Review"],
    architecture: ["Document ingest", "Extraction model", "Classification", "Validation rules", "Review UI", "Export"],
    ctas: [{ label: "Explore prototype" }, { label: "View document workflow", hash: "workflow" }],
    media: { image: s3 },
  },
  {
    slug: "expansion-joint-automation",
    number: "S1",
    title: "Expansion Joint Engineering Automation",
    tier: "specialized",
    industry: "Industrial Equipment Engineering",
    status: ["Delivered Components"],
    statusNote: "Delivered components.",
    summary: "Engineering calculations, BOM preparation, costing, and technical documentation workflows.",
    problem: "Expansion joint design involves repeated calculations, BOM preparation, and documentation for each enquiry.",
    approach: "Structured inputs feed a calculation engine whose outputs drive the BOM, costing, and documents.",
    features: [
      { name: "Engineering calculations", state: "Implemented" },
      { name: "BOM preparation", state: "Implemented" },
      { name: "Costing", state: "Implemented" },
      { name: "Technical documentation", state: "To verify" },
    ],
    flow: ["Inputs", "Calculations", "BOM", "Costing", "Documents"],
    architecture: ["Input templates", "Calculation engine", "BOM schema", "Document output"],
    ctas: [{ label: "View system" }, { label: "View workflow", hash: "workflow" }],
    media: { image: p1w },
  },
  {
    slug: "pressure-vessel-tools",
    number: "S2",
    title: "Pressure Vessel Engineering Tools",
    tier: "specialized",
    industry: "Industrial Equipment Engineering",
    status: ["Delivered Components", "In Development"],
    statusNote: "Delivered components with further development ongoing.",
    summary: "Pressure vessel calculation and engineering workflow automation.",
    problem: "Vessel design calculations are repeated by hand across similar enquiries.",
    approach: "Reusable calculation workflows with structured inputs and consistent outputs.",
    features: [
      { name: "Design calculations", state: "Implemented" },
      { name: "Engineering workflow automation", state: "In development" },
    ],
    flow: ["Inputs", "Calculations", "Outputs"],
    architecture: ["Input templates", "Calculation engine", "Report output"],
    ctas: [{ label: "View system" }, { label: "View workflow", hash: "workflow" }],
    media: { image: s2 },
  },
  {
    slug: "vendor-registration",
    number: "S3",
    title: "Vendor Registration Automation",
    tier: "specialized",
    industry: "Procurement / Operations",
    status: ["Planned"],
    statusNote: "Proposed workflow. Not built.",
    summary: "A proposed workflow for organizing vendor documentation and registration processes.",
    problem: "Vendor documents arrive through email and are tracked manually.",
    approach: "A structured intake and checklist workflow for vendor registration.",
    features: [
      { name: "Vendor document intake", state: "Planned" },
      { name: "Registration checklist", state: "Planned" },
    ],
    flow: ["Intake", "Checklist", "Approval"],
    architecture: ["Intake form", "Document store", "Approval workflow"],
    ctas: [{ label: "View concept" }, { label: "View workflow", hash: "workflow" }],
    media: { image: p3w },
  },
  {
    slug: "workforce-resource-management",
    number: "S4",
    title: "Workforce & Resource Management",
    tier: "specialized",
    industry: "Operations",
    status: ["In Development"],
    statusNote: "Current implementation to be verified by Swayam before publishing.",
    summary: "Operational software concepts and tools for attendance, workforce information, and resource allocation.",
    problem: "Attendance and allocation data is held in separate registers and spreadsheets.",
    approach: "A shared workforce record with attendance and allocation views.",
    features: [
      { name: "Attendance", state: "To verify" },
      { name: "Workforce information", state: "To verify" },
      { name: "Resource allocation", state: "To verify" },
    ],
    flow: ["Attendance", "Records", "Allocation"],
    architecture: ["Web client", "Workforce records", "Allocation views"],
    ctas: [{ label: "View system" }, { label: "View workflow", hash: "workflow" }],
    media: { image: s1 },
  },
  {
    slug: "medpulse",
    number: "R1",
    title: "MedPulse",
    tier: "research",
    industry: "Applied AI Research",
    status: ["Research"],
    statusNote: "Research project. Not a clinical tool; no diagnostic effectiveness is claimed.",
    summary:
      "Research exploring the use of multimodal AI and handwriting-related features for early detection of physician burnout.",
    problem: "Physician burnout is often recognised late; everyday artefacts such as handwriting may carry early signals worth studying.",
    approach: "Combine handwriting-related features with other modalities in a multimodal model, studied as research.",
    features: [
      { name: "Research methodology", state: "Implemented" },
      { name: "Published patent application", state: "Implemented" },
      { name: "Clinical validation", state: "Planned" },
    ],
    flow: ["Handwriting samples", "Feature extraction", "Multimodal fusion", "Research signal"],
    architecture: ["Image preprocessing", "Feature extraction", "Multimodal fusion", "Evaluation"],
    ctas: [{ label: "Read research summary" }, { label: "View method", hash: "workflow" }],
    media: {},
    patent: "202621080973 A",
  },
];

export const flagships = projects.filter((p) => p.tier === "flagship");
export const specialized = projects.filter((p) => p.tier === "specialized");
export const research = projects.filter((p) => p.tier === "research");
export const bySlug = (slug: string) => projects.find((p) => p.slug === slug)!;
