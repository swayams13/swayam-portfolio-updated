import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Cinematic } from "@/components/site/Cinematic";
import { Work } from "@/components/site/Work";
import { About, Contact } from "@/components/site/AboutContact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Swayam Singh — AI & Software for Industry" },
      {
        name: "description",
        content: "Intelligent software systems for manufacturing, EPC, construction, and real estate businesses.",
      },
      { property: "og:title", content: "Swayam Singh — Industry → Intelligence" },
      {
        property: "og:description",
        content: "AI, automation, and custom software for complex industrial operations.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main id="top">
      <a href="#work" className="label sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-20 focus:z-[60] focus:bg-paper focus:p-3 focus:text-charcoal">
        Skip to work
      </a>
      <Nav />
      <Cinematic />
      <Work />
      <About />
      <Contact />
    </main>
  );
}
