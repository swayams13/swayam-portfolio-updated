import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { projects } from "@/lib/content";
import { Nav } from "@/components/site/Nav";
import { StatusTag } from "@/components/site/Work";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const project = projects.find((p) => p.slug === params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.project.title} — Swayam Singh` },
          { name: "description", content: loaderData.project.summary },
          { property: "og:title", content: loaderData.project.title },
          { property: "og:description", content: loaderData.project.summary },
          { property: "og:type", content: "article" },
          { name: "twitter:card", content: "summary_large_image" },
        ]
      : [{ title: "Project not found" }, { name: "robots", content: "noindex" }],
  }),
  component: CaseStudy,
});

function Block({ n, title, id, children }: { n: string; title: string; id?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="scroll-mt-20 grid grid-cols-12 gap-6 border-t border-border py-16">
      <p className="label col-span-12 text-copper md:col-span-3">
        {n} — {title}
      </p>
      <div className="col-span-12 md:col-span-8">{children}</div>
    </section>
  );
}

function CaseStudy() {
  const { project: p } = Route.useLoaderData();
  const related = projects.filter((x) => x.slug !== p.slug && x.tier === p.tier).slice(0, 2);
  return (
    <main>
      <Nav />
      <header className="dark relative flex min-h-[85svh] items-end overflow-hidden bg-charcoal text-foreground">
        {p.media.image && <img src={p.media.image} alt="" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover opacity-50" />}
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal to-transparent" />
        <div className="relative mx-auto w-full max-w-[1600px] px-6 pb-16 md:px-10">
          <div className="flex items-center gap-4">
            <span className="label text-muted-foreground">{p.industry}</span>
            <StatusTag status={p.status} />
          </div>
          <h1 className="display mt-6 max-w-[16ch] text-[clamp(3.5rem,9vw,9rem)]">{p.title}</h1>
        </div>
      </header>
      <div className="mx-auto max-w-[1600px] px-6 md:px-10">
        <Block n="01" title="Overview">
          <p className="text-2xl leading-relaxed">{p.summary}</p>
        </Block>
        <Block n="02" title="Business problem">
          <p className="text-lg leading-relaxed">{p.problem}</p>
        </Block>
        <Block n="03" title="Solution approach" id="workflow">
          <p className="text-lg leading-relaxed">{p.approach}</p>
          <ol className="mt-8 flex flex-wrap gap-3">
            {p.flow.map((s, i) => (
              <li key={s} className="label border border-border px-3 py-2">
                {i + 1}. {s}
              </li>
            ))}
          </ol>
        </Block>
        <div>
          <Block n="04" title="Product demonstration" id="demo">
            <div className="flex aspect-video items-center justify-center border border-dashed border-input bg-secondary">
              <p className="label text-muted-foreground">Walkthrough video & screenshots pending</p>
            </div>
          </Block>
        </div>
        <Block n="05" title="Key features">
          <ul className="divide-y divide-border border-y border-border">
            {p.features.map((f) => (
              <li key={f.name} className="flex justify-between py-4">
                <span>{f.name}</span>
                <span className="label text-muted-foreground">{f.state}</span>
              </li>
            ))}
          </ul>
        </Block>
        <Block n="06" title="System architecture" id="architecture">
          <div>
            <ol className="mt-6 flex flex-wrap items-center gap-3">
              {p.architecture.map((a, i) => (
                <li key={a} className="flex items-center gap-3 font-mono text-sm">
                  <span className="border border-border px-3 py-2">{a}</span>
                  {i < p.architecture.length - 1 && <span className="text-copper">→</span>}
                </li>
              ))}
            </ol>
          </div>
        </Block>
        <Block n="07" title="Status">
          <p className="display text-4xl">{p.status.join(" / ")}</p>
          <p className="mt-3 text-muted-foreground">{p.statusNote} No outcome metrics are shown until verified.</p>
        </Block>
        <Block n="08" title="Related">
          <div className="grid gap-6 sm:grid-cols-2">
            {related.map((r) => (
              <Link key={r.slug} to="/work/$slug" params={{ slug: r.slug }} className="border-t border-foreground pt-4 hover:text-copper">
                <span className="label text-muted-foreground">{r.number} · {r.industry}</span>
                <p className="display mt-2 text-3xl">{r.title}</p>
              </Link>
            ))}
          </div>
        </Block>
        <section className="border-t border-border py-24 text-center">
          <h2 className="display text-6xl">Have a similar challenge?</h2>
          <a href="/#contact" className="label mt-8 inline-block bg-charcoal px-6 py-4 text-paper hover:bg-copper">
            Discuss a project ↗
          </a>
        </section>
      </div>
    </main>
  );
}
